---
name: shift-ledger-design
description: Use this skill to generate well-branded interfaces and assets for Shift Ledger (a food-safety compliance app for hospitality), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, locked status semantics, and domain UI components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Quick reference
- **Global CSS:** link `styles.css` (imports all tokens + Geist fonts). Wrap in `.dark` for dark mode (light is primary).
- **Base:** shadcn/ui + Radix + Tailwind v4 + Lucide, re-themed. Compose from shadcn primitives; do not invent patterns.
- **Brand = indigo** (`#4F46E5` light / `#6366F1` dark). **Neutrals = Slate.** Radius 8 (cards 12). Motion snappy (150–200ms), respect reduced-motion.
- **Components:** React primitives under `components/` → `window.ShadcnUiDesignSystem_fd8ccd` via `_ds_bundle.js`. Load React 18 + the bundle, then `const { Button, StatusBadge } = window.ShadcnUiDesignSystem_fd8ccd`. See each `.prompt.md` for usage.
- **Domain components:** `StatusBadge`, `ThresholdReadout` (live pass/fail temp readout), `NumericKeypad`, `TaskCard`.
- **Icons:** Lucide (https://lucide.dev), 2px stroke, `currentColor`, 16px in controls. No emoji.
- **UI kit:** `ui_kits/shift-ledger/` — mobile app (PIN, Today, Complete-task) + desktop audit export.

## House rules (LOCKED)
- **Status = color + icon + label, always** (color-blind-safe). Never a bare colored dot.
- **Green is ONLY for pass** — never a primary button. Primary actions are indigo.
- Six statuses: pass (green), fail (red), overdue (amber), pending (slate), critical (dark red), info (blue).
- Sentence case everywhere. Terse, calm, imperative copy. Never alarmist except genuine critical failures. No emoji.
- Min touch target 44px. Inputs ≥16px on mobile. Temperatures in Geist Mono with unit.
- The temperature Complete-task flow must feel instant (<10s): ThresholdReadout + NumericKeypad, one primary action, no gratuitous animation.
- Allow ~30% longer German labels; 24h clock; °C.
