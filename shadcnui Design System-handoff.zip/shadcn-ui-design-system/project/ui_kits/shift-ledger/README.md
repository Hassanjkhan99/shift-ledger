# Shift Ledger UI Kit

Interactive recreations of Shift Ledger's core surfaces, built from this design
system's primitives + domain components. Compliance status is always **color +
icon + label**; green means pass and nothing else.

## Screens

### `index.html` — Frontline mobile app (phone 402w)
A full interactive flow on a shared kitchen tablet:
1. **Shared-tablet PIN** (screen 6) — 4-digit unlock, wrong PIN shows a red error state. Demo PIN `2468`.
2. **Today** — header with org switcher + notifications, a due/overdue/done summary strip, To do / Done / All tabs, and a live task list of `TaskCard`s across every state. Bottom nav: Today · Exceptions · Timeline · More (4 max), with an overdue badge.
3. **Complete-task flow** (screen 4, `<10s`) — the completion flow **adapts to the task's `required_evidence`**: a temperature check shows the `ThresholdReadout` + `NumericKeypad` (recolors green/red live); a cleaning check shows a checklist + `EvidenceUpload` (photo) + `SignaturePad`; an allergen check a checklist + sign-off. **Submit is gated** until every required evidence type is present (a "Still needed: …" hint lists what's missing). The **offline** toggle queues the completion as pending-sync and shows its **idempotency key** (F2) so a retry never double-submits. No gratuitous animation — built to feel instant.
4. **Timeline** — the audit ledger: `TimelineRow` entries with actor · action · subject · time, system-actor styling, and **before→after edit** rendering (struck-red → green + reason). **Keyset "Load older" pagination** (F5 — cursor on (time,id), never offset).
5. **Exceptions** — the full state machine (D2): filter chips for open → acknowledged → in_progress → resolved → verified + reopened, each exception showing **severity** (a `critical` cold-chain breach uses the `status-critical` token + AlertOctagon + red border so it reads as more serious) and its workflow state.

### `audit-export.html` — Manager audit records (desktop 1280)
Compliance-manager view: collapsible sidebar with org switcher, a records data table
(result as `StatusBadge`, mono readings, evidence), a filter bar (date range, property,
check type, status), and the **Export dialog** — format toggle, date range, scope, and
the prominent **non-certification disclaimer** (screen 11): *"Not a certification… a
record of self-reported checks… does not guarantee regulatory compliance."* The export
dialog runs on the reusable `Dialog` + `DateRangePicker` + `Combobox`.

### `manager.html` — Manager console (desktop 1280, responsive)
The org-configuration + oversight surface, sidebar-switched across five views:
- **Today rollup** (screen 7 · journey F) — multi-property compliance health cards
  ("Riverside Kitchen 12/14 · 1 overdue · 1 failed", a done/overdue/failed bar), drill
  into a property to see its outlets; org KPI strip on top.
- **Properties & outlets** — the **IANA timezone** is a first-class Combobox (source of
  truth for occurrence wall-clock + DST); `country` (DE/NL) drives which HACCP starter
  pack is offered.
- **User management** — invite-by-email, the **seven canonical roles** via Combobox,
  property-scope assignment, deactivate/reactivate.
- **Templates** — a **flat picker, deliberately not a form/workflow builder**: type +
  threshold + required-evidence + instructions, "Add from DE/NL starter library"
  (clone), and editing reads as **creating a new version** (§22 — never rewrites live
  tasks).
- **Schedules** — template → recurring check: recurrence, time-of-day, assign to a
  **role OR a user (exactly one)**, with "applies to future occurrences only" made
  explicit.
The **⌘K** search sits in the nav as a **reserved placeholder** (post-MVP).

## Composition
All screens are self-contained (inline Babel), composing exported components from
`window.ShadcnUiDesignSystem_fd8ccd` and Lucide icons from CDN. Tables, sidebar, PIN
pad, dialogs, the exception cards, and the bottom nav are semantic HTML styled with the
design tokens. Compression, SHA-256 hashing, and the write-queue are the app's job to
wire — the kit renders the states and gating.
