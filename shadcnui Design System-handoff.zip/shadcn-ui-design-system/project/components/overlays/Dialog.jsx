import React from "react";

const CSS = `
.sl-ovl{position:fixed;inset:0;z-index:1200;background:hsl(222.2 47.4% 11.2% / 0.45);display:flex;animation:sl-ovl-in .2s ease}
@keyframes sl-ovl-in{from{opacity:0}to{opacity:1}}
.sl-dialog{position:relative;z-index:1300;margin:auto;width:520px;max-width:calc(100vw - 32px);max-height:calc(100vh - 48px);overflow:auto;background:var(--popover);color:var(--popover-foreground);border:1px solid var(--border);border-radius:var(--radius-xl);box-shadow:var(--shadow-lg);animation:sl-dialog-in .3s cubic-bezier(0.16,1,0.3,1)}
.sl-dialog--sm{width:400px}
.sl-dialog--lg{width:680px}
@keyframes sl-dialog-in{from{opacity:0;transform:translateY(8px) scale(.98)}to{opacity:1;transform:none}}
.sl-dialog__x{position:absolute;top:14px;right:14px;width:32px;height:32px;border-radius:var(--radius-md);border:none;background:transparent;color:var(--muted-foreground);display:flex;align-items:center;justify-content:center;cursor:pointer}
.sl-dialog__x:hover{background:var(--muted);color:var(--foreground)}
.sl-dialog__x svg{width:17px;height:17px}
.sl-dialog__head{padding:20px 22px 4px}
.sl-dialog__title{font-size:18px;font-weight:600;letter-spacing:-0.01em;margin:0}
.sl-dialog__desc{margin:5px 0 0;font-size:13px;color:var(--muted-foreground);line-height:1.5}
.sl-dialog__body{padding:14px 22px}
.sl-dialog__foot{padding:14px 22px 18px;display:flex;justify-content:flex-end;gap:10px;flex-wrap:wrap}
@media (prefers-reduced-motion: reduce){.sl-ovl,.sl-dialog{animation:none}}
`;

function ensureStyle(id, css) {
  if (typeof document !== "undefined" && !document.getElementById(id)) {
    const s = document.createElement("style");
    s.id = id; s.textContent = css; document.head.appendChild(s);
  }
}
const FOCUSABLE = 'a[href],button:not([disabled]),textarea,input,select,[tabindex]:not([tabindex="-1"])';

function useDismiss(open, onOpenChange, ref) {
  React.useEffect(() => {
    if (!open) return;
    const prev = document.activeElement;
    const onKey = (e) => {
      if (e.key === "Escape") { e.stopPropagation(); onOpenChange && onOpenChange(false); }
      if (e.key === "Tab" && ref.current) {
        const f = ref.current.querySelectorAll(FOCUSABLE);
        if (!f.length) return;
        const first = f[0], last = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    };
    document.addEventListener("keydown", onKey, true);
    const t = setTimeout(() => {
      if (ref.current) {
        const f = ref.current.querySelector(FOCUSABLE);
        (f || ref.current).focus();
      }
    }, 40);
    const overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey, true);
      clearTimeout(t);
      document.body.style.overflow = overflow;
      if (prev && prev.focus) prev.focus();
    };
  }, [open, onOpenChange, ref]);
}

const XIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18M6 6l12 12" /></svg>
);

/**
 * Dialog — a centered modal. Radix-equivalent behavior: focus trap, Escape to close,
 * backdrop click to close, body scroll lock, focus restored on close.
 */
export function Dialog({ open, onOpenChange, size = "default", showClose = true, className = "", children, ...props }) {
  ensureStyle("sl-dialog-css", CSS);
  const ref = React.useRef(null);
  useDismiss(open, onOpenChange, ref);
  if (!open) return null;
  return (
    <div className="sl-ovl" onMouseDown={(e) => { if (e.target === e.currentTarget) onOpenChange && onOpenChange(false); }}>
      <div
        ref={ref}
        data-slot="dialog"
        role="dialog"
        aria-modal="true"
        tabIndex={-1}
        className={["sl-dialog", size !== "default" ? `sl-dialog--${size}` : "", className].filter(Boolean).join(" ")}
        {...props}
      >
        {showClose && (
          <button className="sl-dialog__x" aria-label="Close" onClick={() => onOpenChange && onOpenChange(false)}><XIcon /></button>
        )}
        {children}
      </div>
    </div>
  );
}
export function DialogHeader({ className = "", children, ...p }) {
  return <div className={["sl-dialog__head", className].filter(Boolean).join(" ")} {...p}>{children}</div>;
}
export function DialogTitle({ className = "", children, ...p }) {
  return <h2 className={["sl-dialog__title", className].filter(Boolean).join(" ")} {...p}>{children}</h2>;
}
export function DialogDescription({ className = "", children, ...p }) {
  return <p className={["sl-dialog__desc", className].filter(Boolean).join(" ")} {...p}>{children}</p>;
}
export function DialogBody({ className = "", children, ...p }) {
  return <div className={["sl-dialog__body", className].filter(Boolean).join(" ")} {...p}>{children}</div>;
}
export function DialogFooter({ className = "", children, ...p }) {
  return <div className={["sl-dialog__foot", className].filter(Boolean).join(" ")} {...p}>{children}</div>;
}
