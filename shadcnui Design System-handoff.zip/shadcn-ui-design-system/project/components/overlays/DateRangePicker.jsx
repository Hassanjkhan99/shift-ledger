import React from "react";

const CSS = `
.sl-dp{position:relative;font-family:var(--font-sans)}
.sl-dp__trigger{height:36px;min-width:200px;display:flex;align-items:center;gap:9px;border-radius:var(--radius-md);border:1px solid var(--input);background:transparent;padding:0 12px;font-size:14px;color:var(--foreground);box-shadow:var(--shadow-xs);cursor:pointer;font-family:inherit}
.sl-dp__trigger:focus-visible{outline:none;border-color:var(--ring);box-shadow:0 0 0 3px color-mix(in oklab,var(--ring) 40%,transparent)}
.sl-dp__trigger[data-placeholder=true]{color:var(--muted-foreground)}
.sl-dp__trigger svg{width:15px;height:15px;color:var(--muted-foreground);flex-shrink:0}
.sl-dp__pop{position:absolute;z-index:1400;top:calc(100% + 4px);left:0;width:288px;background:var(--popover);border:1px solid var(--border);border-radius:var(--radius-md);box-shadow:var(--shadow-lg);overflow:hidden;animation:sl-dp-in .14s ease}
@keyframes sl-dp-in{from{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:none}}
@media (prefers-reduced-motion: reduce){.sl-dp__pop{animation:none}}
.sl-dp__hd{display:flex;align-items:center;justify-content:space-between;padding:10px 12px 2px}
.sl-dp__hd b{font-size:14px;font-weight:600}
.sl-dp__navbtn{width:30px;height:30px;border-radius:var(--radius-sm);border:1px solid var(--border);background:var(--card);display:flex;align-items:center;justify-content:center;cursor:pointer;color:var(--foreground)}
.sl-dp__navbtn:hover{background:var(--muted)}
.sl-dp__navbtn svg{width:15px;height:15px}
.sl-dp__grid{display:grid;grid-template-columns:repeat(7,1fr);gap:2px;padding:6px 12px}
.sl-dp__dow{font-size:11px;color:var(--muted-foreground);text-align:center;padding:4px 0;font-weight:500}
.sl-dp__day{height:34px;border:none;background:transparent;border-radius:var(--radius-sm);font-size:13px;color:var(--foreground);cursor:pointer;font-family:inherit;font-variant-numeric:tabular-nums}
.sl-dp__day:hover{background:var(--accent)}
.sl-dp__day--out{visibility:hidden;pointer-events:none}
.sl-dp__day--in{background:var(--accent);border-radius:0}
.sl-dp__day--edge{background:var(--primary);color:var(--primary-foreground)}
.sl-dp__day--edge:hover{background:var(--primary)}
.sl-dp__day--start{border-radius:var(--radius-sm) 0 0 var(--radius-sm)}
.sl-dp__day--end{border-radius:0 var(--radius-sm) var(--radius-sm) 0}
.sl-dp__foot{display:flex;justify-content:space-between;align-items:center;padding:9px 12px 12px;border-top:1px solid var(--border)}
.sl-dp__lbl{font-size:12px;color:var(--muted-foreground);font-family:var(--font-mono)}
.sl-dp__clear{background:transparent;border:none;color:var(--muted-foreground);font-size:13px;font-weight:500;cursor:pointer;font-family:inherit}
.sl-dp__clear:hover{color:var(--foreground)}
`;

function ensureStyle(id, css) {
  if (typeof document !== "undefined" && !document.getElementById(id)) {
    const s = document.createElement("style");
    s.id = id; s.textContent = css; document.head.appendChild(s);
  }
}
const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
const DOW = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"];
const CAL = <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M8 2v4M16 2v4M3 10h18" /><rect width="18" height="18" x="3" y="4" rx="2" /></svg>;
const L = <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m15 18-6-6 6-6" /></svg>;
const R = <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m9 18 6-6-6-6" /></svg>;

const ymd = (d) => d ? new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime() : null;
const fmt = (d) => d ? `${d.getDate()} ${MONTHS[d.getMonth()].slice(0, 3)}` : "";

/** DateRangePicker — a from→to calendar range (Monday-first). For the audit filter bar & schedules. */
export function DateRangePicker({ value, onChange, placeholder = "Pick a date range", className = "", ...props }) {
  ensureStyle("sl-dp-css", CSS);
  const [open, setOpen] = React.useState(false);
  const [from, setFrom] = React.useState(value && value.from ? value.from : null);
  const [to, setTo] = React.useState(value && value.to ? value.to : null);
  const [view, setView] = React.useState(() => { const b = (value && value.from) || new Date(); return new Date(b.getFullYear(), b.getMonth(), 1); });
  const rootRef = React.useRef(null);

  React.useEffect(() => {
    if (!open) return;
    const onDown = (e) => { if (rootRef.current && !rootRef.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [open]);

  const pick = (day) => {
    if (!from || (from && to)) { setFrom(day); setTo(null); return; }
    if (ymd(day) < ymd(from)) { setFrom(day); return; }
    setTo(day);
    if (onChange) onChange({ from, to: day });
  };
  const clear = () => { setFrom(null); setTo(null); if (onChange) onChange({ from: null, to: null }); };

  // build grid (Monday-first)
  const y = view.getFullYear(), m = view.getMonth();
  const first = new Date(y, m, 1);
  const offset = (first.getDay() + 6) % 7;
  const days = new Date(y, m + 1, 0).getDate();
  const cells = [];
  for (let i = 0; i < offset; i++) cells.push(null);
  for (let d = 1; d <= days; d++) cells.push(new Date(y, m, d));

  const label = from ? (to ? `${fmt(from)} – ${fmt(to)} ${to.getFullYear()}` : `${fmt(from)} …`) : "";

  return (
    <div ref={rootRef} className={["sl-dp", className].filter(Boolean).join(" ")} {...props}>
      <button type="button" className="sl-dp__trigger" data-placeholder={!from} aria-haspopup="dialog" aria-expanded={open} onClick={() => setOpen((o) => !o)}>
        {CAL}<span>{label || placeholder}</span>
      </button>
      {open && (
        <div className="sl-dp__pop" role="dialog" aria-label="Choose date range">
          <div className="sl-dp__hd">
            <button className="sl-dp__navbtn" aria-label="Previous month" onClick={() => setView(new Date(y, m - 1, 1))}>{L}</button>
            <b>{MONTHS[m]} {y}</b>
            <button className="sl-dp__navbtn" aria-label="Next month" onClick={() => setView(new Date(y, m + 1, 1))}>{R}</button>
          </div>
          <div className="sl-dp__grid">
            {DOW.map((d) => <div key={d} className="sl-dp__dow">{d}</div>)}
            {cells.map((day, i) => {
              if (!day) return <div key={i} className="sl-dp__day sl-dp__day--out" />;
              const t = ymd(day), f = ymd(from), e = ymd(to);
              const isEdge = t === f || (e && t === e);
              const inRange = f && e && t > f && t < e;
              const cls = ["sl-dp__day"];
              if (inRange) cls.push("sl-dp__day--in");
              if (isEdge) { cls.push("sl-dp__day--edge"); if (t === f && e) cls.push("sl-dp__day--start"); if (e && t === e) cls.push("sl-dp__day--end"); }
              return <button key={i} className={cls.join(" ")} onClick={() => pick(day)}>{day.getDate()}</button>;
            })}
          </div>
          <div className="sl-dp__foot">
            <span className="sl-dp__lbl">{label || "Select start & end"}</span>
            <button className="sl-dp__clear" onClick={clear}>Clear</button>
          </div>
        </div>
      )}
    </div>
  );
}
