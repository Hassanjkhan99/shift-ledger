**Combobox** — searchable single-select (role / property / outlet picker).

```jsx
<Combobox
  options={[{value:"mgr",label:"Manager"},{value:"staff",label:"Staff"},{value:"auditor",label:"Auditor"}]}
  value={role}
  onValueChange={setRole}
  placeholder="Select a role"
/>
```

Popover with a filter box; arrow keys + Enter to pick, Escape / outside-click to close. Controlled via `value` + `onValueChange`.
