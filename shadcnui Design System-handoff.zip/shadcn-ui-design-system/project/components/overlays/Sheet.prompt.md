**Sheet** — edge-anchored panel; the mobile counterpart to Dialog. Same dismiss behavior.

```jsx
<Sheet open={open} onOpenChange={setOpen} side="bottom">
  <SheetHeader>
    <SheetTitle>Complete check</SheetTitle>
    <SheetDescription>Confirm the reading below.</SheetDescription>
  </SheetHeader>
  <SheetBody>…</SheetBody>
  <SheetFooter><Button>Save</Button></SheetFooter>
</Sheet>
```

`side`: `bottom` (default, grab handle) for mobile; `right` for a desktop side panel.
