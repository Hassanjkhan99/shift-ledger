import * as React from "react";

/**
 * A centered modal dialog. Controlled via `open` + `onOpenChange`. Mirrors Radix
 * Dialog behavior: focus is trapped, Escape and backdrop-click close it, body scroll
 * is locked, and focus returns to the trigger on close. Compose with `DialogHeader`
 * (`DialogTitle` + `DialogDescription`), `DialogBody`, and `DialogFooter`.
 *
 * @startingPoint section="Overlays" subtitle="Centered modal dialog" viewport="640x420"
 */
export interface DialogProps extends React.HTMLAttributes<HTMLDivElement> {
  open: boolean;
  onOpenChange?: (open: boolean) => void;
  /** @default "default" */
  size?: "sm" | "default" | "lg";
  /** Show the top-right close button. @default true */
  showClose?: boolean;
}

export function Dialog(props: DialogProps): React.JSX.Element | null;
export function DialogHeader(props: React.HTMLAttributes<HTMLDivElement>): React.JSX.Element;
export function DialogTitle(props: React.HTMLAttributes<HTMLHeadingElement>): React.JSX.Element;
export function DialogDescription(props: React.HTMLAttributes<HTMLParagraphElement>): React.JSX.Element;
export function DialogBody(props: React.HTMLAttributes<HTMLDivElement>): React.JSX.Element;
export function DialogFooter(props: React.HTMLAttributes<HTMLDivElement>): React.JSX.Element;
