import * as React from "react";

/**
 * A panel that slides in from a screen edge — the mobile counterpart to `Dialog`.
 * `side="bottom"` is the bottom sheet (default, with a grab handle); `side="right"`
 * is a side panel. Same dismiss behavior as Dialog (Escape, backdrop, focus trap,
 * scroll lock). Compose with SheetHeader/Title/Description/Body/Footer.
 *
 * @startingPoint section="Overlays" subtitle="Bottom / side sheet" viewport="420x520"
 */
export interface SheetProps extends React.HTMLAttributes<HTMLDivElement> {
  open: boolean;
  onOpenChange?: (open: boolean) => void;
  /** @default "bottom" */
  side?: "bottom" | "right";
  /** Show the grab handle on the bottom sheet. @default true */
  showGrab?: boolean;
}

export function Sheet(props: SheetProps): React.JSX.Element | null;
export function SheetHeader(props: React.HTMLAttributes<HTMLDivElement>): React.JSX.Element;
export function SheetTitle(props: React.HTMLAttributes<HTMLHeadingElement>): React.JSX.Element;
export function SheetDescription(props: React.HTMLAttributes<HTMLParagraphElement>): React.JSX.Element;
export function SheetBody(props: React.HTMLAttributes<HTMLDivElement>): React.JSX.Element;
export function SheetFooter(props: React.HTMLAttributes<HTMLDivElement>): React.JSX.Element;
