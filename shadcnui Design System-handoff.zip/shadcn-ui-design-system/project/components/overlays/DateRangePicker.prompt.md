**DateRangePicker** — from→to calendar range (Monday-first) for the audit filter bar & schedules.

```jsx
const [range, setRange] = useState({ from: null, to: null });
<DateRangePicker value={range} onChange={setRange} placeholder="Pick a date range" />
```

Click a start day then an end day; the span highlights and `onChange({from,to})` fires. Trigger shows "1 Sep – 16 Sep 2025". Clear resets. Escape / outside-click closes.
