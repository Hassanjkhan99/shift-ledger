import React from "react";

const CSS = `
.sl-sheet-ovl{position:fixed;inset:0;z-index:1200;background:hsl(222.2 47.4% 11.2% / 0.45);display:flex;animation:sl-sheet-fade .2s ease}
@keyframes sl-sheet-fade{from{opacity:0}to{opacity:1}}
.sl-sheet{position:relative;z-index:1300;background:var(--popover);color:var(--popover-foreground);border:1px solid var(--border);display:flex;flex-direction:column;box-shadow:var(--shadow-lg)}
.sl-sheet--bottom{margin-top:auto;width:100%;max-height:88vh;border-radius:var(--radius-xl) var(--radius-xl) 0 0;animation:sl-sheet-up .3s cubic-bezier(0.16,1,0.3,1)}
.sl-sheet--right{margin-left:auto;height:100%;width:400px;max-width:92vw;border-radius:0;animation:sl-sheet-right .3s cubic-bezier(0.16,1,0.3,1)}
@keyframes sl-sheet-up{from{transform:translateY(100%)}to{transform:none}}
@keyframes sl-sheet-right{from{transform:translateX(100%)}to{transform:none}}
.sl-sheet__grab{width:36px;height:4px;border-radius:2px;background:var(--border);margin:10px auto 2px}
.sl-sheet__head{padding:8px 20px 4px}
.sl-sheet__title{font-size:17px;font-weight:600;letter-spacing:-0.01em;margin:0}
.sl-sheet__desc{margin:4px 0 0;font-size:13px;color:var(--muted-foreground)}
.sl-sheet__body{padding:12px 20px;overflow:auto}
.sl-sheet__foot{padding:12px 20px 22px;display:flex;gap:10px;flex-direction:column}
@media (prefers-reduced-motion: reduce){.sl-sheet-ovl,.sl-sheet{animation:none}}
`;

function ensureStyle(id, css) {
  if (typeof document !== "undefined" && !document.getElementById(id)) {
    const s = document.createElement("style");
    s.id = id; s.textContent = css; document.head.appendChild(s);
  }
}
const FOCUSABLE = 'a[href],button:not([disabled]),textarea,input,select,[tabindex]:not([tabindex="-1"])';

/**
 * Sheet — a panel that slides in from an edge. The mobile counterpart to Dialog
 * (bottom sheet); also supports a right side panel. Same dismiss behavior.
 */
export function Sheet({ open, onOpenChange, side = "bottom", showGrab = true, className = "", children, ...props }) {
  ensureStyle("sl-sheet-css", CSS);
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (!open) return;
    const prev = document.activeElement;
    const onKey = (e) => {
      if (e.key === "Escape") { e.stopPropagation(); onOpenChange && onOpenChange(false); }
      if (e.key === "Tab" && ref.current) {
        const f = ref.current.querySelectorAll(FOCUSABLE);
        if (!f.length) return;
        const first = f[0], last = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    };
    document.addEventListener("keydown", onKey, true);
    const t = setTimeout(() => { if (ref.current) { const f = ref.current.querySelector(FOCUSABLE); (f || ref.current).focus(); } }, 40);
    const overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.removeEventListener("keydown", onKey, true); clearTimeout(t); document.body.style.overflow = overflow; if (prev && prev.focus) prev.focus(); };
  }, [open, onOpenChange]);
  if (!open) return null;
  return (
    <div className="sl-sheet-ovl" onMouseDown={(e) => { if (e.target === e.currentTarget) onOpenChange && onOpenChange(false); }}>
      <div ref={ref} data-slot="sheet" role="dialog" aria-modal="true" tabIndex={-1} className={["sl-sheet", `sl-sheet--${side}`, className].filter(Boolean).join(" ")} {...props}>
        {side === "bottom" && showGrab && <div className="sl-sheet__grab" />}
        {children}
      </div>
    </div>
  );
}
export function SheetHeader({ className = "", children, ...p }) {
  return <div className={["sl-sheet__head", className].filter(Boolean).join(" ")} {...p}>{children}</div>;
}
export function SheetTitle({ className = "", children, ...p }) {
  return <h2 className={["sl-sheet__title", className].filter(Boolean).join(" ")} {...p}>{children}</h2>;
}
export function SheetDescription({ className = "", children, ...p }) {
  return <p className={["sl-sheet__desc", className].filter(Boolean).join(" ")} {...p}>{children}</p>;
}
export function SheetBody({ className = "", children, ...p }) {
  return <div className={["sl-sheet__body", className].filter(Boolean).join(" ")} {...p}>{children}</div>;
}
export function SheetFooter({ className = "", children, ...p }) {
  return <div className={["sl-sheet__foot", className].filter(Boolean).join(" ")} {...p}>{children}</div>;
}
