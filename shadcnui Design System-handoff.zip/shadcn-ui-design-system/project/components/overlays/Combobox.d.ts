import * as React from "react";

export interface ComboboxOption {
  value: string;
  label: string;
}

/**
 * A searchable single-select — the role/property picker. Popover with a filter input,
 * hover/arrow-key active state, Enter to choose, Escape / outside-click to close.
 * Controlled via `value` + `onValueChange`.
 *
 * @startingPoint section="Overlays" subtitle="Searchable select" viewport="360x300"
 */
export interface ComboboxProps
  extends Omit<React.HTMLAttributes<HTMLDivElement>, "onChange"> {
  options: ComboboxOption[];
  value?: string;
  onValueChange?: (value: string) => void;
  placeholder?: string;
  searchPlaceholder?: string;
}

export function Combobox(props: ComboboxProps): React.JSX.Element;
