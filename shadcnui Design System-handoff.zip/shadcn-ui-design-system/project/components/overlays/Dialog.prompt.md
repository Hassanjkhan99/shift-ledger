**Dialog** — centered modal. Controlled; focus-trapped, Escape / backdrop close, scroll-locked (Radix-equivalent).

```jsx
const [open, setOpen] = useState(false);
<Dialog open={open} onOpenChange={setOpen}>
  <DialogHeader>
    <DialogTitle>Export audit records</DialogTitle>
    <DialogDescription>142 records match your filters.</DialogDescription>
  </DialogHeader>
  <DialogBody>…form…</DialogBody>
  <DialogFooter>
    <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
    <Button onClick={confirm}>Download</Button>
  </DialogFooter>
</Dialog>
```

`size`: sm / default / lg. Use `Sheet` instead for the mobile bottom-sheet pattern.
