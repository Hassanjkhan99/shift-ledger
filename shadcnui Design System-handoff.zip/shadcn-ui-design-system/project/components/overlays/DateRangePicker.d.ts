import * as React from "react";

export interface DateRange {
  from: Date | null;
  to: Date | null;
}

/**
 * A from→to date range picker (Monday-first calendar) for the audit-export filter bar
 * and schedule settings. Click a start day, then an end day; the range highlights and
 * `onChange({from,to})` fires. Controlled via `value`; Escape / outside-click closes.
 *
 * @startingPoint section="Overlays" subtitle="Date range picker" viewport="320x360"
 */
export interface DateRangePickerProps
  extends Omit<React.HTMLAttributes<HTMLDivElement>, "onChange"> {
  value?: DateRange;
  onChange?: (range: DateRange) => void;
  placeholder?: string;
}

export function DateRangePicker(props: DateRangePickerProps): React.JSX.Element;
