import React from "react";

const CSS = `
.sl-cbx{position:relative;font-family:var(--font-sans)}
.sl-cbx__trigger{height:36px;width:100%;display:flex;align-items:center;justify-content:space-between;gap:8px;border-radius:var(--radius-md);border:1px solid var(--input);background:transparent;padding:0 10px 0 12px;font-size:14px;color:var(--foreground);box-shadow:var(--shadow-xs);cursor:pointer;font-family:inherit}
.sl-cbx__trigger:focus-visible{outline:none;border-color:var(--ring);box-shadow:0 0 0 3px color-mix(in oklab,var(--ring) 40%,transparent)}
.sl-cbx__trigger[data-placeholder=true]{color:var(--muted-foreground)}
.sl-cbx__trigger svg{width:15px;height:15px;color:var(--muted-foreground);flex-shrink:0}
.sl-cbx__pop{position:absolute;z-index:1400;top:calc(100% + 4px);left:0;width:100%;min-width:200px;background:var(--popover);border:1px solid var(--border);border-radius:var(--radius-md);box-shadow:var(--shadow-lg);overflow:hidden;animation:sl-cbx-in .14s ease}
@keyframes sl-cbx-in{from{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:none}}
@media (prefers-reduced-motion: reduce){.sl-cbx__pop{animation:none}}
.sl-cbx__search{display:flex;align-items:center;gap:8px;padding:8px 10px;border-bottom:1px solid var(--border)}
.sl-cbx__search svg{width:15px;height:15px;color:var(--muted-foreground);flex-shrink:0}
.sl-cbx__search input{border:none;outline:none;background:transparent;font-size:14px;width:100%;color:var(--foreground);font-family:inherit}
.sl-cbx__list{max-height:220px;overflow:auto;padding:4px}
.sl-cbx__opt{display:flex;align-items:center;gap:8px;padding:8px 10px;border-radius:var(--radius-sm);font-size:14px;cursor:pointer;color:var(--foreground)}
.sl-cbx__opt[data-active=true]{background:var(--accent);color:var(--accent-foreground)}
.sl-cbx__opt svg{width:15px;height:15px;margin-left:auto;color:var(--primary)}
.sl-cbx__empty{padding:16px;text-align:center;font-size:13px;color:var(--muted-foreground)}
`;

function ensureStyle(id, css) {
  if (typeof document !== "undefined" && !document.getElementById(id)) {
    const s = document.createElement("style");
    s.id = id; s.textContent = css; document.head.appendChild(s);
  }
}
const CHEVRON = <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m7 15 5 5 5-5M7 9l5-5 5 5" /></svg>;
const CHECK = <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6 9 17l-5-5" /></svg>;
const SEARCH = <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8" /><path d="m21 21-4.3-4.3" /></svg>;

/** Combobox — a searchable single-select (role / property picker). Popover with filter + keyboard nav. */
export function Combobox({ options = [], value, onValueChange, placeholder = "Select…", searchPlaceholder = "Search…", className = "", ...props }) {
  ensureStyle("sl-cbx-css", CSS);
  const [open, setOpen] = React.useState(false);
  const [q, setQ] = React.useState("");
  const [active, setActive] = React.useState(0);
  const rootRef = React.useRef(null);
  const inputRef = React.useRef(null);
  const selected = options.find((o) => o.value === value);
  const filtered = options.filter((o) => o.label.toLowerCase().includes(q.toLowerCase()));

  React.useEffect(() => {
    if (!open) return;
    const onDown = (e) => { if (rootRef.current && !rootRef.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", onDown);
    const t = setTimeout(() => inputRef.current && inputRef.current.focus(), 30);
    return () => { document.removeEventListener("mousedown", onDown); clearTimeout(t); };
  }, [open]);

  const choose = (o) => { onValueChange && onValueChange(o.value); setOpen(false); setQ(""); };
  const onKey = (e) => {
    if (e.key === "Escape") return setOpen(false);
    if (e.key === "ArrowDown") { e.preventDefault(); setActive((a) => Math.min(a + 1, filtered.length - 1)); }
    else if (e.key === "ArrowUp") { e.preventDefault(); setActive((a) => Math.max(a - 1, 0)); }
    else if (e.key === "Enter") { e.preventDefault(); if (filtered[active]) choose(filtered[active]); }
  };

  return (
    <div ref={rootRef} className={["sl-cbx", className].filter(Boolean).join(" ")} {...props}>
      <button type="button" className="sl-cbx__trigger" data-placeholder={!selected} aria-haspopup="listbox" aria-expanded={open} onClick={() => setOpen((o) => !o)}>
        <span>{selected ? selected.label : placeholder}</span>
        {CHEVRON}
      </button>
      {open && (
        <div className="sl-cbx__pop" role="listbox">
          <div className="sl-cbx__search">
            {SEARCH}
            <input ref={inputRef} value={q} placeholder={searchPlaceholder} onChange={(e) => { setQ(e.target.value); setActive(0); }} onKeyDown={onKey} />
          </div>
          <div className="sl-cbx__list">
            {filtered.map((o, i) => (
              <div key={o.value} role="option" aria-selected={o.value === value} data-active={i === active} className="sl-cbx__opt" onMouseEnter={() => setActive(i)} onClick={() => choose(o)}>
                <span>{o.label}</span>
                {o.value === value ? CHECK : null}
              </div>
            ))}
            {filtered.length === 0 && <div className="sl-cbx__empty">No matches</div>}
          </div>
        </div>
      )}
    </div>
  );
}
