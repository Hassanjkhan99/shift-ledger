**Feedback & navigation** — Alert, Progress, Tabs.

```jsx
<Alert>
  <InfoIcon />
  <AlertTitle>Heads up!</AlertTitle>
  <AlertDescription>You can add components to your app.</AlertDescription>
</Alert>

<Progress value={62} />

<Tabs defaultValue="account">
  <TabsList>
    <TabsTrigger value="account">Account</TabsTrigger>
    <TabsTrigger value="password">Password</TabsTrigger>
  </TabsList>
  <TabsContent value="account">Account panel</TabsContent>
  <TabsContent value="password">Password panel</TabsContent>
</Tabs>
```

Alert `variant="destructive"` tints title + icon with `--destructive`. Progress track is `--primary` at 20%. Tabs list sits on `--muted`; the active trigger lifts to `--background` with `--shadow-sm`.
