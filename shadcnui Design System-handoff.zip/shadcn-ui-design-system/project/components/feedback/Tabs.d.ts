import * as React from "react";

/**
 * Segmented tabs. Compose: `Tabs` (holds state) > `TabsList` > `TabsTrigger value`,
 * then `TabsContent value` for each panel. Controlled via `value`+`onValueChange`
 * or uncontrolled via `defaultValue`.
 */
export interface TabsProps extends React.HTMLAttributes<HTMLDivElement> {
  defaultValue?: string;
  value?: string;
  onValueChange?: (value: string) => void;
}

export function Tabs(props: TabsProps): React.JSX.Element;
export function TabsList(props: React.HTMLAttributes<HTMLDivElement>): React.JSX.Element;
export function TabsTrigger(props: React.HTMLAttributes<HTMLButtonElement> & { value: string }): React.JSX.Element;
export function TabsContent(props: React.HTMLAttributes<HTMLDivElement> & { value: string }): React.JSX.Element;
