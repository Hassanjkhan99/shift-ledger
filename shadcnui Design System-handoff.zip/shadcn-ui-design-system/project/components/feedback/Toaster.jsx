import React from "react";

const CSS = `
.sl-toaster{position:fixed;left:50%;bottom:24px;transform:translateX(-50%);z-index:1500;display:flex;flex-direction:column;gap:8px;align-items:center;width:max-content;max-width:calc(100vw - 32px);pointer-events:none}
.sl-toast{pointer-events:auto;display:flex;align-items:flex-start;gap:10px;background:var(--popover);color:var(--popover-foreground);border:1px solid var(--border);padding:12px 14px;border-radius:var(--radius-md);box-shadow:var(--shadow-lg);min-width:260px;max-width:440px;animation:sl-toast-in .3s cubic-bezier(0.16,1,0.3,1)}
@keyframes sl-toast-in{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}
.sl-toast__ic{width:18px;height:18px;flex-shrink:0;margin-top:1px}
.sl-toast--success .sl-toast__ic{color:var(--status-pass)}
.sl-toast--error .sl-toast__ic{color:var(--status-fail)}
.sl-toast--info .sl-toast__ic{color:var(--status-info)}
.sl-toast--warning .sl-toast__ic{color:var(--status-overdue)}
.sl-toast__body{flex:1;min-width:0}
.sl-toast__title{font-size:14px;font-weight:500;line-height:1.35}
.sl-toast__desc{font-size:13px;color:var(--muted-foreground);margin-top:2px;line-height:1.4}
.sl-toast__action{background:transparent;border:1px solid var(--border);color:var(--foreground);font-size:12px;font-weight:500;padding:6px 11px;border-radius:var(--radius-sm);cursor:pointer;flex-shrink:0;align-self:center;font-family:var(--font-sans)}
.sl-toast__action:hover{background:var(--muted)}
.sl-toast__x{background:transparent;border:none;color:var(--muted-foreground);cursor:pointer;padding:0;width:18px;height:18px;flex-shrink:0}
.sl-toast__x:hover{color:var(--foreground)}
@media (prefers-reduced-motion: reduce){.sl-toast{animation:none}}
`;

function ensureStyle(id, css) {
  if (typeof document !== "undefined" && !document.getElementById(id)) {
    const s = document.createElement("style");
    s.id = id; s.textContent = css; document.head.appendChild(s);
  }
}

// --- module-level store (one queue shared across the bundle) ---
let queue = [];
let listeners = [];
let seq = 0;
function emit() { listeners.forEach((l) => l(queue.slice())); }
function dismiss(id) { queue = queue.filter((t) => t.id !== id); emit(); }
function show(opts) {
  const o = typeof opts === "string" ? { title: opts } : (opts || {});
  const id = o.id != null ? o.id : ++seq;
  const t = { id, variant: o.variant || "info", title: o.title, description: o.description, action: o.action };
  queue = [...queue.filter((x) => x.id !== id), t];
  emit();
  const dur = o.duration == null ? 3200 : o.duration;
  if (dur > 0) setTimeout(() => dismiss(id), dur);
  return id;
}

const I = (p) => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p} />;
const ICONS = {
  success: <I><circle cx="12" cy="12" r="10" /><path d="m9 12 2 2 4-4" /></I>,
  error: <I><circle cx="12" cy="12" r="10" /><path d="m15 9-6 6M9 9l6 6" /></I>,
  info: <I><circle cx="12" cy="12" r="10" /><path d="M12 16v-4M12 8h.01" /></I>,
  warning: <I><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z" /><path d="M12 9v4M12 17h.01" /></I>,
};
const X = <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" width="18" height="18"><path d="M18 6 6 18M6 6l12 12" /></svg>;

/**
 * Toaster — mount once near the app root. Fire toasts imperatively from anywhere via
 * Toaster.show / .success / .error / .info / .warning. Uses a polite aria-live region.
 */
export function Toaster({ className = "", ...props }) {
  ensureStyle("sl-toast-css", CSS);
  const [items, setItems] = React.useState(queue.slice());
  React.useEffect(() => {
    listeners.push(setItems);
    setItems(queue.slice());
    return () => { listeners = listeners.filter((l) => l !== setItems); };
  }, []);
  return (
    <div className={["sl-toaster", className].filter(Boolean).join(" ")} role="region" aria-live="polite" aria-label="Notifications" {...props}>
      {items.map((t) => (
        <div key={t.id} className={`sl-toast sl-toast--${t.variant}`} role="status">
          <span className="sl-toast__ic">{ICONS[t.variant] || ICONS.info}</span>
          <div className="sl-toast__body">
            {t.title ? <div className="sl-toast__title">{t.title}</div> : null}
            {t.description ? <div className="sl-toast__desc">{t.description}</div> : null}
          </div>
          {t.action ? (
            <button className="sl-toast__action" onClick={() => { t.action.onClick && t.action.onClick(); dismiss(t.id); }}>{t.action.label}</button>
          ) : null}
          <button className="sl-toast__x" aria-label="Dismiss" onClick={() => dismiss(t.id)}>{X}</button>
        </div>
      ))}
    </div>
  );
}
Toaster.show = show;
Toaster.dismiss = dismiss;
Toaster.success = (o) => show({ ...(typeof o === "string" ? { title: o } : o), variant: "success" });
Toaster.error = (o) => show({ ...(typeof o === "string" ? { title: o } : o), variant: "error" });
Toaster.info = (o) => show({ ...(typeof o === "string" ? { title: o } : o), variant: "info" });
Toaster.warning = (o) => show({ ...(typeof o === "string" ? { title: o } : o), variant: "warning" });
