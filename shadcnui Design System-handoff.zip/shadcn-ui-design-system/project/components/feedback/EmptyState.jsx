import React from "react";

const CSS = `
.sl-empty{display:flex;flex-direction:column;align-items:center;text-align:center;padding:44px 24px;gap:5px}
.sl-empty--compact{padding:28px 20px}
.sl-empty__ic{width:52px;height:52px;border-radius:var(--radius-lg);background:var(--muted);color:var(--muted-foreground);display:flex;align-items:center;justify-content:center;margin-bottom:8px}
.sl-empty__ic svg{width:24px;height:24px}
.sl-empty__title{font-size:16px;font-weight:600;color:var(--foreground)}
.sl-empty__desc{font-size:14px;color:var(--muted-foreground);max-width:320px;line-height:1.5}
.sl-empty__action{margin-top:14px}
`;

function ensureStyle(id, css) {
  if (typeof document !== "undefined" && !document.getElementById(id)) {
    const s = document.createElement("style");
    s.id = id; s.textContent = css; document.head.appendChild(s);
  }
}
const DEFAULT_ICON = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 12h-6l-2 3h-4l-2-3H2" /><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z" /></svg>
);

/** EmptyState — the "nothing here yet" placeholder for a list/screen, with an optional CTA. */
export function EmptyState({ icon, title, description, action, compact = false, className = "", ...props }) {
  ensureStyle("sl-empty-css", CSS);
  return (
    <div data-slot="empty-state" className={["sl-empty", compact ? "sl-empty--compact" : "", className].filter(Boolean).join(" ")} {...props}>
      <span className="sl-empty__ic">{icon || DEFAULT_ICON}</span>
      {title ? <div className="sl-empty__title">{title}</div> : null}
      {description ? <div className="sl-empty__desc">{description}</div> : null}
      {action ? <div className="sl-empty__action">{action}</div> : null}
    </div>
  );
}
