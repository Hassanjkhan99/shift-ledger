**Toaster** — m**ount once; fire toasts imperatively from anywhere.**

```jsx
// once, near the app root:
<Toaster />

// anywhere:
Toaster.success("Check passed — 3°C");
Toaster.error({ title: "Upload failed", description: "Tap to retry", action: { label: "Retry", onClick: retry } });
Toaster.info({ title: "Queued for sync", duration: 0 }); // sticky until dismissed
```

**Variants `success` / `error` / `info` / `warning` (colored icon on a dark toast). Bottom-center, polite `aria-live`. `duration: 0` keeps it until dismissed.**
