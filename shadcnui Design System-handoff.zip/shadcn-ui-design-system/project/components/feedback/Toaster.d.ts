import * as React from "react";

export type ToastVariant = "success" | "error" | "info" | "warning";

export interface ToastOptions {
  id?: number | string;
  title?: React.ReactNode;
  description?: React.ReactNode;
  variant?: ToastVariant;
  /** Auto-dismiss ms; 0 keeps it until dismissed. @default 3200 */
  duration?: number;
  /** Optional action button. */
  action?: { label: string; onClick?: () => void };
}

/**
 * Mount `<Toaster />` once near the app root, then fire toasts imperatively from
 * anywhere: `Toaster.show(opts)` or the `Toaster.success/error/info/warning`
 * shorthands (each accepts a string or ToastOptions). Renders bottom-center in a
 * polite aria-live region (Radix Toast-equivalent a11y).
 *
 * @startingPoint section="Feedback" subtitle="Toaster + imperative toast API" viewport="480x200"
 */
export interface ToasterProps extends React.HTMLAttributes<HTMLDivElement> {}

export function Toaster(props: ToasterProps): React.JSX.Element;
export namespace Toaster {
  function show(opts: ToastOptions | string): number | string;
  function dismiss(id: number | string): void;
  function success(opts: ToastOptions | string): number | string;
  function error(opts: ToastOptions | string): number | string;
  function info(opts: ToastOptions | string): number | string;
  function warning(opts: ToastOptions | string): number | string;
}
