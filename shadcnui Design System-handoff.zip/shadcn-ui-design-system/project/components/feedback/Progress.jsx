import React from "react";

const CSS = `
.scn-progress{position:relative;width:100%;height:.5rem;overflow:hidden;border-radius:var(--radius-full);background:color-mix(in oklab,var(--primary) 20%,transparent)}
.scn-progress-bar{height:100%;background:var(--primary);border-radius:inherit;transition:width .3s ease}
`;

function ensureStyle(id, css) {
  if (typeof document !== "undefined" && !document.getElementById(id)) {
    const s = document.createElement("style");
    s.id = id;
    s.textContent = css;
    document.head.appendChild(s);
  }
}

/** Progress — a horizontal completion bar (0–100). */
export function Progress({ value = 0, className = "", ...props }) {
  ensureStyle("scn-progress-css", CSS);
  const pct = Math.max(0, Math.min(100, value));
  return (
    <div
      data-slot="progress"
      role="progressbar"
      aria-valuemin={0}
      aria-valuemax={100}
      aria-valuenow={pct}
      className={["scn-progress", className].filter(Boolean).join(" ")}
      {...props}
    >
      <div className="scn-progress-bar" style={{ width: `${pct}%` }} />
    </div>
  );
}
