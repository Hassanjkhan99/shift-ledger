import * as React from "react";

/**
 * A contextual callout box. Put an SVG icon as the first child to get the
 * icon layout, then `AlertTitle` + `AlertDescription`.
 */
export interface AlertProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: "default" | "destructive";
}

export function Alert(props: AlertProps): React.JSX.Element;
export function AlertTitle(props: React.HTMLAttributes<HTMLDivElement>): React.JSX.Element;
export function AlertDescription(props: React.HTMLAttributes<HTMLDivElement>): React.JSX.Element;
