import React from "react";

const CSS = `
.scn-tabs{display:flex;flex-direction:column;gap:.5rem}
.scn-tabs-list{display:inline-flex;height:2.25rem;width:fit-content;align-items:center;justify-content:center;gap:.25rem;border-radius:var(--radius-lg);background:var(--muted);padding:3px;color:var(--muted-foreground)}
.scn-tabs-trigger{display:inline-flex;height:100%;align-items:center;justify-content:center;gap:.375rem;border-radius:var(--radius-md);border:1px solid transparent;padding:0 .75rem;font-family:var(--font-sans);font-size:var(--text-sm);font-weight:var(--font-weight-medium);color:var(--muted-foreground);white-space:nowrap;cursor:pointer;background:transparent;transition:color .15s ease,background .15s ease,box-shadow .15s ease;outline:none}
.scn-tabs-trigger svg{width:1rem;height:1rem}
.scn-tabs-trigger[data-state=active]{background:var(--background);color:var(--foreground);box-shadow:var(--shadow-sm)}
.scn-tabs-trigger:focus-visible{box-shadow:0 0 0 3px color-mix(in oklab,var(--ring) 50%,transparent)}
.scn-tabs-content{outline:none}
`;

function ensureStyle(id, css) {
  if (typeof document !== "undefined" && !document.getElementById(id)) {
    const s = document.createElement("style");
    s.id = id;
    s.textContent = css;
    document.head.appendChild(s);
  }
}
function cx(b, c) {
  return [b, c].filter(Boolean).join(" ");
}

const TabsCtx = React.createContext(null);

/** Tabs — switch between panels. Compose with TabsList/TabsTrigger/TabsContent; `value` matches trigger to content. */
export function Tabs({ defaultValue, value, onValueChange, className = "", children, ...props }) {
  ensureStyle("scn-tabs-css", CSS);
  const [internal, setInternal] = React.useState(defaultValue);
  const isControlled = value !== undefined;
  const val = isControlled ? value : internal;
  const setVal = (v) => {
    if (!isControlled) setInternal(v);
    if (onValueChange) onValueChange(v);
  };
  return (
    <div data-slot="tabs" className={cx("scn-tabs", className)} {...props}>
      <TabsCtx.Provider value={{ val, setVal }}>{children}</TabsCtx.Provider>
    </div>
  );
}
export function TabsList({ className = "", children, ...props }) {
  return (
    <div role="tablist" data-slot="tabs-list" className={cx("scn-tabs-list", className)} {...props}>
      {children}
    </div>
  );
}
export function TabsTrigger({ value, className = "", children, ...props }) {
  const ctx = React.useContext(TabsCtx);
  const active = ctx && ctx.val === value;
  return (
    <button
      type="button"
      role="tab"
      aria-selected={active}
      data-slot="tabs-trigger"
      data-state={active ? "active" : "inactive"}
      onClick={() => ctx && ctx.setVal(value)}
      className={cx("scn-tabs-trigger", className)}
      {...props}
    >
      {children}
    </button>
  );
}
export function TabsContent({ value, className = "", children, ...props }) {
  const ctx = React.useContext(TabsCtx);
  if (!ctx || ctx.val !== value) return null;
  return (
    <div role="tabpanel" data-slot="tabs-content" className={cx("scn-tabs-content", className)} {...props}>
      {children}
    </div>
  );
}
