import * as React from "react";

/**
 * The visible half of the offline write-queue (D9): a status strip showing connection
 * state and how many checks are queued to sync. Pairs with the pending-sync markers on
 * `TaskCard` and `EvidenceUpload`. Use `full` for an edge-to-edge banner under a header.
 *
 * @startingPoint section="Feedback" subtitle="Offline / syncing banner (D9)" viewport="480x120"
 */
export interface OfflineBannerProps
  extends React.HTMLAttributes<HTMLDivElement> {
  /** @default "offline" */
  variant?: "offline" | "syncing" | "error";
  /** Override the default message for the variant. */
  message?: React.ReactNode;
  /** Number of checks waiting to sync (shown when no onRetry). */
  queuedCount?: number;
  /** Show a "Retry now" action instead of the queued count. */
  onRetry?: () => void;
  /** Edge-to-edge (no radius), for pinning under a header. @default false */
  full?: boolean;
}

export function OfflineBanner(props: OfflineBannerProps): React.JSX.Element;
