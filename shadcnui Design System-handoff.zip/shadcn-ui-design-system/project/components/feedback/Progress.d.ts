import * as React from "react";

/** A determinate horizontal progress bar. */
export interface ProgressProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Completion, 0–100. @default 0 */
  value?: number;
}

export function Progress(props: ProgressProps): React.JSX.Element;
