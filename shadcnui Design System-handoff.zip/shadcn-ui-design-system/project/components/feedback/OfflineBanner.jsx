import React from "react";

const CSS = `
.sl-offline{display:flex;align-items:center;gap:10px;padding:10px 14px;font-size:13px;font-weight:500;border-radius:var(--radius-md);font-family:var(--font-sans)}
.sl-offline--full{border-radius:0;justify-content:center;width:100%}
.sl-offline--offline{background:var(--status-overdue-bg);color:var(--status-overdue-fg);border:1px solid color-mix(in oklab,var(--status-overdue) 30%,transparent)}
.sl-offline--full.sl-offline--offline{border-left:0;border-right:0;border-top:0}
.sl-offline--syncing{background:var(--status-info-bg);color:var(--status-info-fg);border:1px solid color-mix(in oklab,var(--status-info) 30%,transparent)}
.sl-offline--error{background:var(--status-fail-bg);color:var(--status-fail-fg);border:1px solid color-mix(in oklab,var(--status-fail) 30%,transparent)}
.sl-offline__ic{width:16px;height:16px;flex-shrink:0}
.sl-offline__spin{animation:sl-off-spin .8s linear infinite}
@keyframes sl-off-spin{to{transform:rotate(360deg)}}
@media (prefers-reduced-motion: reduce){.sl-offline__spin{animation:none}}
.sl-offline__count{margin-left:auto;font-family:var(--font-mono);opacity:.9;white-space:nowrap}
.sl-offline__retry{margin-left:auto;background:transparent;border:none;color:inherit;font-weight:600;cursor:pointer;text-decoration:underline;font-size:13px;font-family:var(--font-sans)}
`;

function ensureStyle(id, css) {
  if (typeof document !== "undefined" && !document.getElementById(id)) {
    const s = document.createElement("style");
    s.id = id; s.textContent = css; document.head.appendChild(s);
  }
}
const I = (p) => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p} />;
const CLOUD_OFF = <I className="sl-offline__ic"><path d="m2 2 20 20" /><path d="M5.782 5.782A7 7 0 0 0 9 19h8.5a4.5 4.5 0 0 0 1.307-.193" /><path d="M21.532 16.5A4.5 4.5 0 0 0 17.5 10h-1.79A7.008 7.008 0 0 0 10 5.07" /></I>;
const SYNC = <I className="sl-offline__ic sl-offline__spin"><path d="M21 12a9 9 0 1 1-6.219-8.56" /></I>;
const ALERT = <I className="sl-offline__ic"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z" /><path d="M12 9v4M12 17h.01" /></I>;

const DEFAULTS = {
  offline: { icon: CLOUD_OFF, msg: "You're offline — checks are saved and will sync automatically." },
  syncing: { icon: SYNC, msg: "Back online — syncing queued checks…" },
  error: { icon: ALERT, msg: "Sync failed — we'll keep retrying." },
};

/**
 * OfflineBanner — the visible half of the offline write-queue (D9). Shows connection
 * state and how many checks are waiting to sync. Pairs with the pending-sync markers
 * on TaskCard / EvidenceUpload.
 */
export function OfflineBanner({ variant = "offline", message, queuedCount, onRetry, full = false, className = "", ...props }) {
  ensureStyle("sl-offline-css", CSS);
  const d = DEFAULTS[variant] || DEFAULTS.offline;
  return (
    <div data-slot="offline-banner" role="status" className={["sl-offline", `sl-offline--${variant}`, full ? "sl-offline--full" : "", className].filter(Boolean).join(" ")} {...props}>
      {d.icon}
      <span>{message || d.msg}</span>
      {onRetry ? (
        <button className="sl-offline__retry" onClick={onRetry}>Retry now</button>
      ) : queuedCount != null ? (
        <span className="sl-offline__count">{queuedCount} queued</span>
      ) : null}
    </div>
  );
}
