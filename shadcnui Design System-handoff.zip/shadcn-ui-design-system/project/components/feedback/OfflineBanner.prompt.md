**Empty state, skeletons & offline banner** — the per-screen state components.

```jsx
<EmptyState title="Nothing due right now" description="New checks appear here as they're scheduled."
  action={<Button variant="outline">View all tasks</Button>} />

<Skeleton style={{height:12, width:"70%"}} />   {/* loading placeholder */}

<OfflineBanner variant="offline" queuedCount={3} full />
<OfflineBanner variant="syncing" />
<OfflineBanner variant="error" onRetry={retry} />
```

`OfflineBanner` is the visible half of the offline write-queue (D9); `variant`: offline / syncing / error. `Skeleton` (in Display) is the shimmer placeholder. `EmptyState` takes icon + title + description + one action.
