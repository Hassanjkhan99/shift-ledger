import React from "react";

const CSS = `
.scn-alert{position:relative;display:grid;grid-template-columns:0 1fr;width:100%;align-items:start;gap:.125rem .75rem;border-radius:var(--radius-lg);border:1px solid var(--border);padding:.75rem 1rem;font-family:var(--font-sans);font-size:var(--text-sm);background:var(--card);color:var(--card-foreground)}
.scn-alert:has(>svg){grid-template-columns:1rem 1fr}
.scn-alert>svg{width:1rem;height:1rem;transform:translateY(2px);color:currentColor}
.scn-alert-title{grid-column-start:2;font-weight:var(--font-weight-medium);letter-spacing:-.01em;min-height:1rem;line-height:1rem}
.scn-alert-desc{grid-column-start:2;font-size:var(--text-sm);color:var(--muted-foreground);line-height:1.45}
.scn-alert-v-destructive{color:var(--destructive)}
.scn-alert-v-destructive .scn-alert-desc{color:color-mix(in oklab,var(--destructive) 90%,transparent)}
`;

function ensureStyle(id, css) {
  if (typeof document !== "undefined" && !document.getElementById(id)) {
    const s = document.createElement("style");
    s.id = id;
    s.textContent = css;
    document.head.appendChild(s);
  }
}
function cx(b, c) {
  return [b, c].filter(Boolean).join(" ");
}

/** Alert — a contextual callout. Optionally leads with an icon as the first child. */
export function Alert({ variant = "default", className = "", children, ...props }) {
  ensureStyle("scn-alert-css", CSS);
  return (
    <div data-slot="alert" role="alert" className={cx(`scn-alert scn-alert-v-${variant}`, className)} {...props}>
      {children}
    </div>
  );
}
export function AlertTitle({ className = "", children, ...props }) {
  return (
    <div data-slot="alert-title" className={cx("scn-alert-title", className)} {...props}>
      {children}
    </div>
  );
}
export function AlertDescription({ className = "", children, ...props }) {
  return (
    <div data-slot="alert-description" className={cx("scn-alert-desc", className)} {...props}>
      {children}
    </div>
  );
}
