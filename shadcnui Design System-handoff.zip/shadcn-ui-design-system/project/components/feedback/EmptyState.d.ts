import * as React from "react";

/**
 * The "nothing here" placeholder for an empty list or screen: icon + title +
 * description + one optional CTA. The brief wants one on every screen.
 *
 * @startingPoint section="Feedback" subtitle="Empty-state placeholder" viewport="480x300"
 */
export interface EmptyStateProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Icon node (e.g. a Lucide SVG). Defaults to an inbox glyph. */
  icon?: React.ReactNode;
  title?: React.ReactNode;
  description?: React.ReactNode;
  /** A CTA element, usually a Button. */
  action?: React.ReactNode;
  /** Tighter padding for in-card use. @default false */
  compact?: boolean;
}

export function EmptyState(props: EmptyStateProps): React.JSX.Element;
