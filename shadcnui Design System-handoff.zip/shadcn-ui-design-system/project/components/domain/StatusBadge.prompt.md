**StatusBadge** — the locked compliance status pill. Always renders **color + icon + label** (never color alone). Green is only ever `pass`.

```jsx
<StatusBadge status="pass" />
<StatusBadge status="fail" />
<StatusBadge status="overdue" />
<StatusBadge status="pending" />
<StatusBadge status="critical" />
<StatusBadge status="info">Synced</StatusBadge>   {/* custom label */}
```

Statuses: `pass` (green, CheckCircle2), `fail` (red, XCircle), `overdue` (amber, AlertCircle), `pending` (slate, Circle), `critical` (dark red + border, AlertOctagon), `info` (blue, Info). Sizes `sm`/`md`; `solid` for high-emphasis fills.
