import * as React from "react";

export type EvidenceState =
  | "idle"
  | "capturing"
  | "compressing"
  | "uploaded"
  | "error"
  | "offline-queued";

/**
 * Camera-first photo-evidence widget for a check, rendered across its full lifecycle:
 * idle → capturing → compressing (client-side WebP downscale) → uploaded, plus
 * error/retry and offline-queued (ties into the write-queue and the Today card's
 * pending-sync state). On finalize a SHA-256 is computed over the compressed bytes and
 * surfaced, so the evidence is tamper-evident.
 *
 * @startingPoint section="Domain" subtitle="Evidence upload — all states" viewport="440x220"
 */
export interface EvidenceUploadProps
  extends React.HTMLAttributes<HTMLDivElement> {
  /** Which lifecycle state to render. @default "idle" */
  state?: EvidenceState;
  fileName?: string;
  /** Human size, e.g. "182 KB". */
  fileSize?: string;
  /** Thumbnail image URL once captured. */
  thumbSrc?: string | null;
  /** 0–100, for the compressing state. */
  progress?: number;
  /** SHA-256 hex computed on finalize; shown truncated. */
  hash?: string;
  onTakePhoto?: () => void;
  onChooseFile?: () => void;
  onRetry?: () => void;
  onRemove?: () => void;
}

export function EvidenceUpload(props: EvidenceUploadProps): React.JSX.Element;
