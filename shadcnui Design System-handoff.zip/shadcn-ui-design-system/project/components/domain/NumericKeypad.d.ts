import * as React from "react";

/**
 * Large on-screen numeric keypad for temperature entry (all keys ≥44px). Controlled:
 * pass the current `value` string and handle `onChange(next)`. Supports negatives
 * (freezer) via ± and one decimal point. Pair with `ThresholdReadout`.
 */
export interface NumericKeypadProps
  extends Omit<React.HTMLAttributes<HTMLDivElement>, "onChange"> {
  /** Current entry as a string (e.g. "-18", "4.5"). */
  value?: string;
  /** Called with the next string on each key press. */
  onChange?: (next: string) => void;
  /** Allow the ± sign toggle. @default true */
  allowNegative?: boolean;
  /** Allow a decimal point. @default true */
  allowDecimal?: boolean;
}

export function NumericKeypad(props: NumericKeypadProps): React.JSX.Element;
