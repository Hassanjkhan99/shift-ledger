import * as React from "react";

export type CheckType =
  | "temperature"
  | "cleaning"
  | "allergen"
  | "opening"
  | "closing"
  | "generic";

export type TaskStatus =
  | "due"
  | "upcoming"
  | "overdue"
  | "done"
  | "failed"
  | "pending-sync";

/**
 * A Today-list row for a single compliance check, rendered across its lifecycle:
 * due, upcoming, overdue, done (collapsed/struck), failed, and pending-sync
 * (offline queue). Tap to open/complete.
 *
 * @startingPoint section="Domain" subtitle="Today task row — all states" viewport="420x340"
 */
export interface TaskCardProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  title: string;
  /** Drives the leading icon. @default "generic" */
  checkType?: CheckType;
  /** @default "due" */
  status?: TaskStatus;
  /** Meta label, e.g. "Due 3:00 PM" (shown for due/upcoming/overdue). */
  time?: string;
  /** Recorded result for done/failed rows, e.g. "4°C". */
  result?: string;
}

export function TaskCard(props: TaskCardProps): React.JSX.Element;
