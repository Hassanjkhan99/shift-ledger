import React from "react";
import { StatusBadge } from "./StatusBadge.jsx";

const CSS = `
.sl-ev{width:100%;font-family:var(--font-sans)}
.sl-ev__drop{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;padding:20px;border:1px dashed var(--border);border-radius:var(--radius-lg);background:var(--surface);text-align:center}
.sl-ev__drop-ic{width:40px;height:40px;border-radius:var(--radius-md);background:var(--accent);color:var(--primary);display:flex;align-items:center;justify-content:center}
.sl-ev__drop-ic svg{width:21px;height:21px}
.sl-ev__hint{font-size:13px;color:var(--muted-foreground)}
.sl-ev__actions{display:flex;gap:8px;width:100%;margin-top:2px}
.sl-ev__btn{flex:1;min-height:var(--touch-target);height:44px;display:inline-flex;align-items:center;justify-content:center;gap:7px;border-radius:var(--radius-md);font-family:var(--font-sans);font-size:14px;font-weight:500;cursor:pointer;border:1px solid transparent}
.sl-ev__btn svg{width:17px;height:17px}
.sl-ev__btn--primary{background:var(--primary);color:var(--primary-foreground)}
.sl-ev__btn--primary:hover{background:color-mix(in oklab,var(--primary) 90%,transparent)}
.sl-ev__btn--outline{background:var(--card);border-color:var(--border);color:var(--foreground)}
.sl-ev__btn--outline:hover{background:var(--accent)}
.sl-ev__row{display:flex;align-items:center;gap:12px;padding:12px;border:1px solid var(--border);border-radius:var(--radius-lg);background:var(--card)}
.sl-ev__thumb{width:52px;height:52px;border-radius:var(--radius-md);background:var(--muted);flex-shrink:0;object-fit:cover;display:flex;align-items:center;justify-content:center;color:var(--muted-foreground);overflow:hidden}
.sl-ev__thumb img{width:100%;height:100%;object-fit:cover}
.sl-ev__thumb svg{width:22px;height:22px}
.sl-ev__meta{flex:1;min-width:0;display:flex;flex-direction:column;gap:3px}
.sl-ev__name{font-size:14px;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.sl-ev__sub{font-size:12px;color:var(--muted-foreground);display:flex;align-items:center;gap:6px;flex-wrap:wrap}
.sl-ev__sub svg{width:12px;height:12px}
.sl-ev__hash{font-family:var(--font-mono);font-size:11px;color:var(--muted-foreground);background:var(--muted);padding:2px 6px;border-radius:var(--radius-sm);display:inline-flex;align-items:center;gap:4px}
.sl-ev__hash svg{width:11px;height:11px}
.sl-ev__bar{height:6px;border-radius:var(--radius-full);background:var(--muted);overflow:hidden;margin-top:2px}
.sl-ev__bar-fill{height:100%;background:var(--primary);border-radius:inherit;transition:width .2s ease}
.sl-ev__ico-btn{width:34px;height:34px;flex-shrink:0;border-radius:var(--radius-md);border:1px solid var(--border);background:var(--card);color:var(--muted-foreground);display:flex;align-items:center;justify-content:center;cursor:pointer}
.sl-ev__ico-btn:hover{background:var(--muted);color:var(--foreground)}
.sl-ev__ico-btn svg{width:16px;height:16px}
.sl-ev__spin{width:20px;height:20px;color:var(--primary);animation:sl-ev-spin .7s linear infinite}
@keyframes sl-ev-spin{to{transform:rotate(360deg)}}
.sl-ev__ok{color:var(--status-pass-fg);font-weight:500;display:inline-flex;align-items:center;gap:5px}
.sl-ev__ok svg{width:13px;height:13px}
.sl-ev__err{color:var(--status-fail-fg);font-weight:500;display:inline-flex;align-items:center;gap:5px}
.sl-ev__err svg{width:13px;height:13px}
`;

function ensureStyle(id, css) {
  if (typeof document !== "undefined" && !document.getElementById(id)) {
    const s = document.createElement("style");
    s.id = id; s.textContent = css; document.head.appendChild(s);
  }
}
const I = (p) => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p} />;
const ICON = {
  camera: <I><path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3Z" /><circle cx="12" cy="13" r="3" /></I>,
  upload: <I><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><polyline points="17 8 12 3 7 8" /><line x1="12" y1="3" x2="12" y2="15" /></I>,
  image: <I><rect width="18" height="18" x="3" y="3" rx="2" /><circle cx="9" cy="9" r="2" /><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21" /></I>,
  check: <I><path d="M20 6 9 17l-5-5" /></I>,
  retry: <I><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" /><path d="M3 3v5h5" /></I>,
  cloudOff: <I><path d="m2 2 20 20" /><path d="M5.782 5.782A7 7 0 0 0 9 19h8.5a4.5 4.5 0 0 0 1.307-.193" /><path d="M21.532 16.5A4.5 4.5 0 0 0 17.5 10h-1.79A7.008 7.008 0 0 0 10 5.07" /></I>,
  alert: <I><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z" /><path d="M12 9v4M12 17h.01" /></I>,
  x: <I><path d="M18 6 6 18M6 6l12 12" /></I>,
  lock: <I><rect width="18" height="11" x="3" y="11" rx="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" /></I>,
  alarm: <I><circle cx="12" cy="13" r="8" /><path d="M12 9v4l2 2" /><path d="M5 3 2 6M22 6l-3-3" /></I>,
};

/**
 * EvidenceUpload — camera-first photo evidence widget, across its full lifecycle.
 * On finalize a SHA-256 is computed over the (client-compressed WebP) bytes and shown,
 * so the record is tamper-evident. Offline captures are queued and marked pending-sync.
 */
export function EvidenceUpload({
  state = "idle",
  fileName = "evidence.webp",
  fileSize = "",
  thumbSrc = null,
  progress = 0,
  hash = "",
  onTakePhoto,
  onChooseFile,
  onRetry,
  onRemove,
  className = "",
  ...props
}) {
  ensureStyle("sl-ev-css", CSS);
  const thumb = (
    <span className="sl-ev__thumb">{thumbSrc ? <img src={thumbSrc} alt="" /> : ICON.image}</span>
  );
  let body;
  if (state === "idle") {
    body = (
      <div className="sl-ev__drop">
        <span className="sl-ev__drop-ic">{ICON.camera}</span>
        <span className="sl-ev__hint">Add a photo as evidence for this check</span>
        <div className="sl-ev__actions">
          <button className="sl-ev__btn sl-ev__btn--primary" onClick={onTakePhoto}>{ICON.camera} Take photo</button>
          <button className="sl-ev__btn sl-ev__btn--outline" onClick={onChooseFile}>{ICON.upload} Choose file</button>
        </div>
      </div>
    );
  } else if (state === "capturing") {
    body = (
      <div className="sl-ev__row">
        <span className="sl-ev__thumb"><svg className="sl-ev__spin" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M21 12a9 9 0 1 1-6.219-8.56" /></svg></span>
        <div className="sl-ev__meta"><span className="sl-ev__name">Opening camera…</span><span className="sl-ev__sub">Point at the reading or label</span></div>
      </div>
    );
  } else if (state === "compressing") {
    body = (
      <div className="sl-ev__row">
        {thumb}
        <div className="sl-ev__meta">
          <span className="sl-ev__name">{fileName}</span>
          <span className="sl-ev__sub">Compressing to WebP… {Math.round(progress)}%</span>
          <div className="sl-ev__bar"><div className="sl-ev__bar-fill" style={{ width: `${progress}%` }} /></div>
        </div>
      </div>
    );
  } else if (state === "uploaded") {
    body = (
      <div className="sl-ev__row">
        {thumb}
        <div className="sl-ev__meta">
          <span className="sl-ev__name">{fileName}</span>
          <span className="sl-ev__sub">
            <span className="sl-ev__ok">{ICON.check} Uploaded</span>
            {fileSize ? <span>· {fileSize}</span> : null}
          </span>
          {hash ? <span className="sl-ev__hash">{ICON.lock} SHA-256 {hash.slice(0, 10)}…</span> : null}
        </div>
        <button className="sl-ev__ico-btn" onClick={onRemove} aria-label="Remove">{ICON.x}</button>
      </div>
    );
  } else if (state === "error") {
    body = (
      <div className="sl-ev__row" style={{ borderColor: "var(--status-fail)" }}>
        {thumb}
        <div className="sl-ev__meta">
          <span className="sl-ev__name">{fileName}</span>
          <span className="sl-ev__sub"><span className="sl-ev__err">{ICON.alert} Upload failed</span></span>
        </div>
        <button className="sl-ev__btn sl-ev__btn--outline" style={{ flex: "none", width: "auto", padding: "0 12px", height: 34 }} onClick={onRetry}>{ICON.retry} Retry</button>
      </div>
    );
  } else if (state === "offline-queued") {
    body = (
      <div className="sl-ev__row">
        {thumb}
        <div className="sl-ev__meta">
          <span className="sl-ev__name">{fileName}</span>
          <span className="sl-ev__sub">{ICON.cloudOff} Queued — will sync when back online</span>
        </div>
        <StatusBadge status="pending" size="sm">Queued</StatusBadge>
      </div>
    );
  }
  return (
    <div data-slot="evidence-upload" data-state={state} className={["sl-ev", className].filter(Boolean).join(" ")} {...props}>
      {body}
    </div>
  );
}
