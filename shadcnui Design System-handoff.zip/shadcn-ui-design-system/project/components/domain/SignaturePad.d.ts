import * as React from "react";

export type SignatureMode = "drawn" | "typed";

export interface SignatureValue {
  mode: SignatureMode;
  /** PNG data URL for drawn mode (null if cleared). */
  dataUrl?: string | null;
  /** Uppercased initials for typed mode. */
  initials?: string;
  /** True for drawn (produces an image attachment), false for typed. */
  hasAttachment: boolean;
}

/**
 * Sign-off with an explicit mode choice (decision D4): DRAW a signature (canvas →
 * image attachment) or TYPE initials (text, no attachment). The two are never
 * collapsed — the segmented toggle always shows which mode is active.
 *
 * @startingPoint section="Domain" subtitle="Signature — draw vs type initials" viewport="440x260"
 */
export interface SignaturePadProps
  extends Omit<React.HTMLAttributes<HTMLDivElement>, "onChange"> {
  /** Initial mode. @default "drawn" */
  defaultMode?: SignatureMode;
  /** Which modes to offer; pass one to lock the mode. @default ["drawn","typed"] */
  allowedModes?: SignatureMode[];
  /** Fired on every stroke/keystroke/mode change with the current value. */
  onChange?: (value: SignatureValue) => void;
}

export function SignaturePad(props: SignaturePadProps): React.JSX.Element;
