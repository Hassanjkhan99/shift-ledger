**TimelineRow** — one audit-history entry: actor · action · subject · time, with optional before→after edit rendering.

```jsx
<TimelineRow actor="Ana P." action="completed" subject="Walk-in fridge temp" time="16 Sep · 14:58" />
<TimelineRow actorType="system" actor="System" action="flagged a cold-chain breach on"
  subject="Delivery" time="15 Sep · 22:40" />
<TimelineRow actor="Jordan Diaz" action="edited the reading for" subject="Display fridge temp"
  time="16 Sep · 15:10"
  edit={{ before: "5°C (pass)", after: "9°C (fail)", reason: "Corrected transcription error" }} />
<TimelineRow actor="Ana P." action="signed off shift" time="16 Sep · 18:00" last />
```

`edit` renders the change as struck-through red → green with the reason. `actorType="system"` swaps the initials avatar for a system icon + indigo tint. `last` hides the connector for the final row.
