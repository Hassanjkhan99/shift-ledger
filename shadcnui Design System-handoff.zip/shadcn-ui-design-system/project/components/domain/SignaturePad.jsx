import React from "react";

const CSS = `
.sl-sig{width:100%;font-family:var(--font-sans);display:flex;flex-direction:column;gap:10px}
.sl-sig__toggle{display:flex;gap:6px;background:var(--muted);padding:3px;border-radius:var(--radius-md);width:fit-content}
.sl-sig__tab{display:inline-flex;align-items:center;gap:6px;padding:6px 12px;border-radius:var(--radius-sm);border:none;background:transparent;color:var(--muted-foreground);font-family:var(--font-sans);font-size:13px;font-weight:500;cursor:pointer}
.sl-sig__tab svg{width:15px;height:15px}
.sl-sig__tab[aria-selected=true]{background:var(--background);color:var(--foreground);box-shadow:var(--shadow-sm)}
.sl-sig__canvas-wrap{position:relative;border:1px solid var(--input);border-radius:var(--radius-lg);background:var(--card);overflow:hidden;touch-action:none}
.sl-sig__canvas{display:block;width:100%;height:150px;cursor:crosshair}
.sl-sig__base{position:absolute;left:0;right:0;bottom:34px;border-top:1px dashed var(--border);pointer-events:none}
.sl-sig__ph{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:var(--muted-foreground);font-size:14px;pointer-events:none}
.sl-sig__clear{position:absolute;top:8px;right:8px;display:inline-flex;align-items:center;gap:5px;padding:5px 9px;border-radius:var(--radius-sm);border:1px solid var(--border);background:var(--card);color:var(--muted-foreground);font-size:12px;font-weight:500;cursor:pointer}
.sl-sig__clear svg{width:13px;height:13px}
.sl-sig__typed{display:flex;flex-direction:column;gap:8px}
.sl-sig__input{height:48px;border-radius:var(--radius-md);border:1px solid var(--input);background:transparent;padding:0 14px;font-family:var(--font-sans);font-size:16px;font-weight:500;color:var(--foreground);outline:none;box-shadow:var(--shadow-xs);text-transform:uppercase;letter-spacing:.08em}
.sl-sig__input:focus-visible{border-color:var(--ring);box-shadow:0 0 0 3px color-mix(in oklab,var(--ring) 40%,transparent)}
.sl-sig__preview{height:80px;border-radius:var(--radius-lg);border:1px solid var(--border);background:var(--surface);display:flex;align-items:center;justify-content:center}
.sl-sig__preview span{font-family:var(--font-mono);font-size:34px;font-weight:600;letter-spacing:.12em;color:var(--foreground)}
.sl-sig__preview .ph{font-family:var(--font-sans);font-size:14px;font-weight:400;letter-spacing:0;color:var(--muted-foreground)}
.sl-sig__note{font-size:12px;color:var(--muted-foreground);display:flex;align-items:center;gap:6px}
.sl-sig__note svg{width:13px;height:13px;flex-shrink:0}
`;

function ensureStyle(id, css) {
  if (typeof document !== "undefined" && !document.getElementById(id)) {
    const s = document.createElement("style");
    s.id = id; s.textContent = css; document.head.appendChild(s);
  }
}
const I = (p) => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p} />;
const PEN = <I><path d="M12 20h9" /><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z" /></I>;
const TYPE = <I><polyline points="4 7 4 4 20 4 20 7" /><line x1="9" y1="20" x2="15" y2="20" /><line x1="12" y1="4" x2="12" y2="20" /></I>;
const CLEAR = <I><path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m2 0v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6" /></I>;
const PAPERCLIP = <I><path d="m21.44 11.05-9.19 9.19a6 6 0 0 1-8.49-8.49l8.57-8.57A4 4 0 1 1 18 8.84l-8.59 8.57a2 2 0 0 1-2.83-2.83l8.49-8.48" /></I>;
const INFO = <I><circle cx="12" cy="12" r="10" /><path d="M12 16v-4M12 8h.01" /></I>;

/**
 * SignaturePad — sign-off with an explicit mode choice (decision D4): DRAW a signature
 * (produces an image attachment) or TYPE initials (no attachment). The mode is never
 * collapsed — the segmented toggle always makes the current mode explicit.
 */
export function SignaturePad({
  defaultMode = "drawn",
  allowedModes = ["drawn", "typed"],
  onChange,
  className = "",
  ...props
}) {
  ensureStyle("sl-sig-css", CSS);
  const [mode, setMode] = React.useState(allowedModes.includes(defaultMode) ? defaultMode : allowedModes[0]);
  const [initials, setInitials] = React.useState("");
  const [hasInk, setHasInk] = React.useState(false);
  const canvasRef = React.useRef(null);
  const drawing = React.useRef(false);
  const last = React.useRef(null);

  React.useEffect(() => {
    if (mode !== "drawn") return;
    const cv = canvasRef.current;
    if (!cv) return;
    const dpr = window.devicePixelRatio || 1;
    const rect = cv.getBoundingClientRect();
    cv.width = rect.width * dpr;
    cv.height = rect.height * dpr;
    const ctx = cv.getContext("2d");
    ctx.scale(dpr, dpr);
    ctx.lineWidth = 2.5;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.strokeStyle = getComputedStyle(cv).getPropertyValue("--foreground") || "#0f172a";
  }, [mode]);

  const pos = (e) => {
    const r = canvasRef.current.getBoundingClientRect();
    const p = e.touches ? e.touches[0] : e;
    return { x: p.clientX - r.left, y: p.clientY - r.top };
  };
  const start = (e) => { e.preventDefault(); drawing.current = true; last.current = pos(e); };
  const move = (e) => {
    if (!drawing.current) return;
    e.preventDefault();
    const ctx = canvasRef.current.getContext("2d");
    const p = pos(e);
    ctx.beginPath();
    ctx.moveTo(last.current.x, last.current.y);
    ctx.lineTo(p.x, p.y);
    ctx.stroke();
    last.current = p;
    if (!hasInk) setHasInk(true);
  };
  const end = () => {
    if (!drawing.current) return;
    drawing.current = false;
    if (onChange && canvasRef.current) {
      onChange({ mode: "drawn", dataUrl: canvasRef.current.toDataURL("image/png"), hasAttachment: true });
    }
  };
  const clear = () => {
    const cv = canvasRef.current;
    const ctx = cv.getContext("2d");
    ctx.clearRect(0, 0, cv.width, cv.height);
    setHasInk(false);
    if (onChange) onChange({ mode: "drawn", dataUrl: null, hasAttachment: true });
  };
  const onType = (e) => {
    const v = e.target.value.toUpperCase().slice(0, 4);
    setInitials(v);
    if (onChange) onChange({ mode: "typed", initials: v, hasAttachment: false });
  };
  const pick = (m) => {
    setMode(m);
    if (onChange) onChange(m === "typed" ? { mode: "typed", initials, hasAttachment: false } : { mode: "drawn", dataUrl: hasInk && canvasRef.current ? canvasRef.current.toDataURL("image/png") : null, hasAttachment: true });
  };

  return (
    <div data-slot="signature-pad" data-mode={mode} className={["sl-sig", className].filter(Boolean).join(" ")} {...props}>
      {allowedModes.length > 1 && (
        <div className="sl-sig__toggle" role="tablist">
          <button role="tab" aria-selected={mode === "drawn"} className="sl-sig__tab" onClick={() => pick("drawn")}>{PEN} Draw</button>
          <button role="tab" aria-selected={mode === "typed"} className="sl-sig__tab" onClick={() => pick("typed")}>{TYPE} Type initials</button>
        </div>
      )}
      {mode === "drawn" ? (
        <>
          <div className="sl-sig__canvas-wrap">
            <canvas
              ref={canvasRef}
              className="sl-sig__canvas"
              onMouseDown={start} onMouseMove={move} onMouseUp={end} onMouseLeave={end}
              onTouchStart={start} onTouchMove={move} onTouchEnd={end}
            />
            <div className="sl-sig__base" />
            {!hasInk && <div className="sl-sig__ph">Sign here with your finger or a stylus</div>}
            {hasInk && <button className="sl-sig__clear" onClick={clear}>{CLEAR} Clear</button>}
          </div>
          <div className="sl-sig__note">{PAPERCLIP} Saved as a signature image attached to this record.</div>
        </>
      ) : (
        <div className="sl-sig__typed">
          <input className="sl-sig__input" value={initials} onChange={onType} placeholder="Your initials" maxLength={4} aria-label="Initials" />
          <div className="sl-sig__preview">{initials ? <span>{initials}</span> : <span className="ph">Preview</span>}</div>
          <div className="sl-sig__note">{INFO} Typed initials are recorded as text — no image attachment.</div>
        </div>
      )}
    </div>
  );
}
