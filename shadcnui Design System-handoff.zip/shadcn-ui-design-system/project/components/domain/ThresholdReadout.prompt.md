**ThresholdReadout** — the make-or-break temperature readout. Big Geist Mono value that recolors **green (pass) / red (fail)** live against a threshold; muted "—" when empty. Pair with `NumericKeypad`.

```jsx
// fridge must be ≤ 5°C
<ThresholdReadout value={value} max={5} />

// hot-hold must be ≥ 63°C
<ThresholdReadout value={value} min={63} />

// range
<ThresholdReadout value={value} min={1} max={4} size="xl" />
```

`value` should be the raw string from the keypad (keeps a trailing `.` while typing). Set `min`/`max`/both. `size`: `md` 32 / `lg` 56 / `xl` 72px.
