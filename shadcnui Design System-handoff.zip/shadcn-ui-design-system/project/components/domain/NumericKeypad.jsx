import React from "react";

const CSS = `
.sl-keypad{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;width:100%;max-width:320px}
.sl-key{height:56px;min-height:var(--touch-target);display:flex;align-items:center;justify-content:center;border-radius:var(--radius-md);border:1px solid var(--border);background:var(--card);color:var(--foreground);font-family:var(--font-mono);font-size:22px;font-weight:600;cursor:pointer;user-select:none;transition:background .12s ease,border-color .12s ease,opacity .12s ease;-webkit-tap-highlight-color:transparent}
.sl-key:hover{background:var(--accent)}
.sl-key:active{background:var(--muted);opacity:.7}
.sl-key:focus-visible{outline:none;border-color:var(--ring);box-shadow:0 0 0 3px color-mix(in oklab,var(--ring) 40%,transparent)}
.sl-key--util{font-size:15px;font-weight:500;color:var(--muted-foreground)}
.sl-key svg{width:22px;height:22px}
`;

function ensureStyle(id, css) {
  if (typeof document !== "undefined" && !document.getElementById(id)) {
    const s = document.createElement("style");
    s.id = id;
    s.textContent = css;
    document.head.appendChild(s);
  }
}

/**
 * NumericKeypad — large on-screen keypad for entering temperatures (44px+ targets).
 * Controlled: holds nothing itself; `value` is the current string, `onChange` gets
 * the next string. Supports negatives (freezer) via ± and a single decimal point.
 */
export function NumericKeypad({ value = "", onChange, allowNegative = true, allowDecimal = true, className = "", ...props }) {
  ensureStyle("sl-keypad-css", CSS);
  const set = (next) => onChange && onChange(next);
  const press = (k) => {
    const v = String(value);
    if (k === "back") return set(v.slice(0, -1));
    if (k === "sign") {
      if (!allowNegative) return;
      return set(v.startsWith("-") ? v.slice(1) : "-" + v);
    }
    if (k === ".") {
      if (!allowDecimal || v.includes(".")) return;
      return set(v === "" || v === "-" ? v + "0." : v + ".");
    }
    // digit — cap length to keep readout sane
    if (v.replace("-", "").replace(".", "").length >= 5) return;
    set(v + k);
  };
  const Key = ({ k, children, util }) => (
    <button
      type="button"
      className={["sl-key", util ? "sl-key--util" : ""].filter(Boolean).join(" ")}
      onClick={() => press(k)}
      aria-label={typeof children === "string" ? children : k}
    >
      {children}
    </button>
  );
  return (
    <div data-slot="numeric-keypad" className={["sl-keypad", className].filter(Boolean).join(" ")} {...props}>
      {["1", "2", "3", "4", "5", "6", "7", "8", "9"].map((n) => (
        <Key key={n} k={n}>{n}</Key>
      ))}
      <Key k="sign" util>±</Key>
      <Key k="0">0</Key>
      {allowDecimal ? (
        <Key k=".">.</Key>
      ) : (
        <Key k="back" util>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 4H8l-7 8 7 8h13a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2Z" /><path d="m18 9-6 6" /><path d="m12 9 6 6" /></svg>
        </Key>
      )}
      {allowDecimal && (
        <button
          type="button"
          className="sl-key sl-key--util"
          onClick={() => press("back")}
          aria-label="Backspace"
          style={{ gridColumn: "1 / -1" }}
        >
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 4H8l-7 8 7 8h13a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2Z" /><path d="m18 9-6 6" /><path d="m12 9 6 6" /></svg>
        </button>
      )}
    </div>
  );
}
