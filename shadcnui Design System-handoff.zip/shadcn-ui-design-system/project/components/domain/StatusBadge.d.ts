import * as React from "react";

export type ComplianceStatus =
  | "pass"
  | "fail"
  | "overdue"
  | "pending"
  | "critical"
  | "info";

/**
 * The LOCKED compliance status pill. Status is **never** conveyed by color alone —
 * this component always renders color + Lucide icon + text label together. Green is
 * reserved exclusively for `pass`.
 *
 * @startingPoint section="Domain" subtitle="Locked compliance status pill" viewport="700x200"
 */
export interface StatusBadgeProps
  extends React.HTMLAttributes<HTMLSpanElement> {
  /** Which compliance status. @default "pending" */
  status?: ComplianceStatus;
  /** @default "md" */
  size?: "sm" | "md";
  /** Solid fill (for high-emphasis contexts) instead of the subtle tint. @default false */
  solid?: boolean;
  /** Override the default label text (e.g. localized). */
  children?: React.ReactNode;
}

export function StatusBadge(props: StatusBadgeProps): React.JSX.Element;
