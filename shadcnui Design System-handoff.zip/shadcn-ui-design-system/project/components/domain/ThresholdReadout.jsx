import React from "react";
import { StatusBadge } from "./StatusBadge.jsx";

const CSS = `
.sl-readout{display:flex;flex-direction:column;align-items:center;gap:10px;text-align:center}
.sl-readout__value{font-family:var(--font-mono);font-weight:var(--readout-weight);line-height:var(--readout-line);letter-spacing:-0.02em;font-variant-numeric:tabular-nums;display:flex;align-items:baseline;gap:2px}
.sl-readout__unit{font-size:.5em;font-weight:500}
.sl-readout--pass .sl-readout__value{color:var(--status-pass)}
.sl-readout--fail .sl-readout__value{color:var(--status-fail)}
.sl-readout--empty .sl-readout__value{color:var(--muted-foreground)}
.sl-readout__hint{font-size:13px;color:var(--muted-foreground)}
.sl-readout__hint b{color:var(--foreground);font-weight:500;font-family:var(--font-mono)}
`;

function ensureStyle(id, css) {
  if (typeof document !== "undefined" && !document.getElementById(id)) {
    const s = document.createElement("style");
    s.id = id;
    s.textContent = css;
    document.head.appendChild(s);
  }
}

const SIZES = { md: 32, lg: 56, xl: 72 };

function thresholdText(min, max, unit) {
  if (min != null && max != null) return <>Target <b>{min}–{max}{unit}</b></>;
  if (max != null) return <>Must be <b>≤ {max}{unit}</b></>;
  if (min != null) return <>Must be <b>≥ {min}{unit}</b></>;
  return null;
}

/**
 * ThresholdReadout — the hero of the temperature-check flow. A large Geist Mono
 * value that recolors green (pass) / red (fail) live against a threshold.
 */
export function ThresholdReadout({
  value,
  unit = "°C",
  min = null,
  max = null,
  size = "lg",
  showBadge = true,
  showHint = true,
  className = "",
  ...props
}) {
  ensureStyle("sl-readout-css", CSS);
  const empty = value === null || value === undefined || value === "" || value === "-";
  const num = empty ? null : Number(value);
  const invalid = !empty && Number.isNaN(num);
  let state = "empty";
  if (!empty && !invalid) {
    const okMin = min == null || num >= min;
    const okMax = max == null || num <= max;
    state = okMin && okMax ? "pass" : "fail";
  }
  const px = SIZES[size] || SIZES.lg;
  return (
    <div
      data-slot="threshold-readout"
      data-state={state}
      className={["sl-readout", `sl-readout--${state}`, className].filter(Boolean).join(" ")}
      {...props}
    >
      <div className="sl-readout__value" style={{ fontSize: px }}>
        {empty ? "—" : value}
        <span className="sl-readout__unit">{unit}</span>
      </div>
      {showHint && thresholdText(min, max, unit) && (
        <div className="sl-readout__hint">{thresholdText(min, max, unit)}</div>
      )}
      {showBadge && !empty && !invalid && (
        <StatusBadge status={state === "pass" ? "pass" : "fail"} />
      )}
    </div>
  );
}
