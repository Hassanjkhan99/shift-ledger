import React from "react";

const CSS = `
.sl-badge{display:inline-flex;align-items:center;gap:6px;border-radius:var(--radius-full);border:1px solid transparent;font-family:var(--font-sans);font-weight:500;white-space:nowrap;width:fit-content;line-height:1}
.sl-badge svg{flex-shrink:0}
.sl-badge--md{padding:5px 11px 5px 9px;font-size:13px}
.sl-badge--md svg{width:15px;height:15px}
.sl-badge--sm{padding:3px 8px 3px 7px;font-size:12px}
.sl-badge--sm svg{width:13px;height:13px}
.sl-badge--pass{background:var(--status-pass-bg);color:var(--status-pass-fg)}
.sl-badge--fail{background:var(--status-fail-bg);color:var(--status-fail-fg)}
.sl-badge--overdue{background:var(--status-overdue-bg);color:var(--status-overdue-fg)}
.sl-badge--pending{background:var(--status-pending-bg);color:var(--status-pending-fg)}
.sl-badge--critical{background:var(--status-critical-bg);color:var(--status-critical-fg);border-color:var(--status-critical)}
.sl-badge--info{background:var(--status-info-bg);color:var(--status-info-fg)}
.sl-badge--solid.sl-badge--pass{background:var(--status-pass);color:#fff}
.sl-badge--solid.sl-badge--fail{background:var(--status-fail);color:#fff}
.sl-badge--solid.sl-badge--overdue{background:var(--status-overdue);color:#fff}
.sl-badge--solid.sl-badge--pending{background:var(--status-pending);color:#fff}
.sl-badge--solid.sl-badge--critical{background:var(--status-critical);color:#fff}
.sl-badge--solid.sl-badge--info{background:var(--status-info);color:#fff}
`;

function ensureStyle(id, css) {
  if (typeof document !== "undefined" && !document.getElementById(id)) {
    const s = document.createElement("style");
    s.id = id;
    s.textContent = css;
    document.head.appendChild(s);
  }
}

const P = (props) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.25" strokeLinecap="round" strokeLinejoin="round" {...props} />
);
const ICONS = {
  pass: <P><circle cx="12" cy="12" r="10" /><path d="m9 12 2 2 4-4" /></P>,
  fail: <P><circle cx="12" cy="12" r="10" /><path d="m15 9-6 6" /><path d="m9 9 6 6" /></P>,
  overdue: <P><circle cx="12" cy="12" r="10" /><line x1="12" y1="8" x2="12" y2="12" /><line x1="12" y1="16" x2="12.01" y2="16" /></P>,
  pending: <P><circle cx="12" cy="12" r="10" /></P>,
  critical: <P><path d="M7.86 2h8.28L22 7.86v8.28L16.14 22H7.86L2 16.14V7.86z" /><line x1="12" y1="8" x2="12" y2="12" /><line x1="12" y1="16" x2="12.01" y2="16" /></P>,
  info: <P><circle cx="12" cy="12" r="10" /><path d="M12 16v-4" /><path d="M12 8h.01" /></P>,
};
const DEFAULT_LABELS = {
  pass: "Pass",
  fail: "Fail",
  overdue: "Overdue",
  pending: "Pending",
  critical: "Critical",
  info: "Info",
};

/** StatusBadge — the LOCKED compliance status pill: always color + icon + label. */
export function StatusBadge({ status = "pending", size = "md", solid = false, children, className = "", ...props }) {
  ensureStyle("sl-badge-css", CSS);
  const cls = [
    "sl-badge",
    `sl-badge--${size}`,
    `sl-badge--${status}`,
    solid ? "sl-badge--solid" : "",
    className,
  ]
    .filter(Boolean)
    .join(" ");
  return (
    <span data-slot="status-badge" data-status={status} className={cls} {...props}>
      {ICONS[status]}
      {children || DEFAULT_LABELS[status]}
    </span>
  );
}
