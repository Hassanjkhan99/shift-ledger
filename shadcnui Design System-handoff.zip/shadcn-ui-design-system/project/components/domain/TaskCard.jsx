import React from "react";
import { StatusBadge } from "./StatusBadge.jsx";

const CSS = `
.sl-task{display:flex;align-items:center;gap:13px;padding:13px 14px;background:var(--card);border:1px solid var(--border);border-radius:var(--radius-xl);min-height:var(--touch-target);cursor:pointer;text-align:left;width:100%;font-family:var(--font-sans);transition:border-color .15s ease,box-shadow .15s ease,opacity .15s ease}
.sl-task:hover{border-color:var(--slate-300);box-shadow:var(--shadow-sm)}
.sl-task:focus-visible{outline:none;border-color:var(--ring);box-shadow:0 0 0 3px color-mix(in oklab,var(--ring) 35%,transparent)}
.sl-task:active{opacity:.7}
.sl-task--done{opacity:.62}
.sl-task__chip{width:40px;height:40px;border-radius:var(--radius-md);display:flex;align-items:center;justify-content:center;flex-shrink:0;background:var(--muted);color:var(--muted-foreground)}
.sl-task__chip svg{width:20px;height:20px}
.sl-task--overdue .sl-task__chip{background:var(--status-overdue-bg);color:var(--status-overdue-fg)}
.sl-task--failed .sl-task__chip{background:var(--status-fail-bg);color:var(--status-fail-fg)}
.sl-task--done .sl-task__chip{background:var(--status-pass-bg);color:var(--status-pass-fg)}
.sl-task__body{flex:1;min-width:0;display:flex;flex-direction:column;gap:3px}
.sl-task__title{font-size:15px;font-weight:500;color:var(--foreground);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.sl-task--done .sl-task__title{text-decoration:line-through;text-decoration-color:var(--muted-foreground)}
.sl-task__meta{font-size:13px;color:var(--muted-foreground);display:flex;align-items:center;gap:6px}
.sl-task__meta svg{width:13px;height:13px;flex-shrink:0}
.sl-task__result{font-family:var(--font-mono);font-weight:600;font-variant-numeric:tabular-nums}
.sl-task__right{display:flex;align-items:center;gap:10px;flex-shrink:0}
.sl-task__chev{width:18px;height:18px;color:var(--slate-400)}
`;

function ensureStyle(id, css) {
  if (typeof document !== "undefined" && !document.getElementById(id)) {
    const s = document.createElement("style");
    s.id = id;
    s.textContent = css;
    document.head.appendChild(s);
  }
}

const S = (props) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props} />
);
const CHECK_ICONS = {
  temperature: <S><path d="M14 4v10.54a4 4 0 1 1-4 0V4a2 2 0 0 1 4 0Z" /></S>,
  cleaning: <S><path d="m3 3 8 8" /><path d="M12.5 6.5 18 12" /><path d="m14 10 7 7a2.828 2.828 0 0 1-4 4l-7-7" /><path d="M5 21v-4a2 2 0 0 1 2-2h4" /></S>,
  allergen: <S><path d="M2 22 16 8" /><path d="M3.47 12.53 5 11l1.53 1.53a3.5 3.5 0 0 1 0 4.94L5 19l-1.53-1.53a3.5 3.5 0 0 1 0-4.94Z" /><path d="M7.47 8.53 9 7l1.53 1.53a3.5 3.5 0 0 1 0 4.94L9 15l-1.53-1.53a3.5 3.5 0 0 1 0-4.94Z" /><path d="M11.47 4.53 13 3l1.53 1.53a3.5 3.5 0 0 1 0 4.94L13 11l-1.53-1.53a3.5 3.5 0 0 1 0-4.94Z" /></S>,
  opening: <S><path d="M12 2v8" /><path d="m4.93 10.93 1.41 1.41" /><path d="M2 18h2" /><path d="M20 18h2" /><path d="m19.07 10.93-1.41 1.41" /><path d="M22 22H2" /><path d="m8 6 4-4 4 4" /><path d="M16 18a4 4 0 0 0-8 0" /></S>,
  closing: <S><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z" /></S>,
  generic: <S><path d="M11 14h1v4" /><path d="M16 2v4" /><path d="M8 2v4" /><path d="M3 10h18" /><rect x="3" y="4" width="18" height="18" rx="2" /><path d="m9 16 1 1 3-3" /></S>,
};

const CLOCK = <S><circle cx="12" cy="12" r="10" /><polyline points="12 6 12 12 16 14" /></S>;
const CLOUD_OFF = <S><path d="m2 2 20 20" /><path d="M5.782 5.782A7 7 0 0 0 9 19h8.5a4.5 4.5 0 0 0 1.307-.193" /><path d="M21.532 16.5A4.5 4.5 0 0 0 17.5 10h-1.79A7.008 7.008 0 0 0 10 5.07" /></S>;
const CHEVRON = <svg className="sl-task__chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m9 18 6-6-6-6" /></svg>;

/** TaskCard — a Today-list row for a compliance check, across its lifecycle states. */
export function TaskCard({
  title,
  checkType = "generic",
  status = "due",
  time,
  result,
  className = "",
  ...props
}) {
  ensureStyle("sl-task-css", CSS);
  const right = () => {
    if (status === "overdue") return <StatusBadge status="overdue" size="sm" />;
    if (status === "failed") return <StatusBadge status="fail" size="sm" />;
    if (status === "done") return <StatusBadge status="pass" size="sm" />;
    if (status === "pending-sync") return <StatusBadge status="pending" size="sm">Syncing</StatusBadge>;
    return CHEVRON;
  };
  const metaContent = () => {
    if (status === "pending-sync") return <>{CLOUD_OFF} Waiting to sync</>;
    if ((status === "done" || status === "failed") && result != null)
      return <><span className="sl-task__result">{result}</span></>;
    return <>{CLOCK} {time}</>;
  };
  return (
    <button
      type="button"
      data-slot="task-card"
      data-status={status}
      className={["sl-task", `sl-task--${status}`, className].filter(Boolean).join(" ")}
      {...props}
    >
      <span className="sl-task__chip">{CHECK_ICONS[checkType] || CHECK_ICONS.generic}</span>
      <span className="sl-task__body">
        <span className="sl-task__title">{title}</span>
        <span className="sl-task__meta">{metaContent()}</span>
      </span>
      <span className="sl-task__right">{right()}</span>
    </button>
  );
}
