**TaskCard** — a Today-list row for one compliance check, across its lifecycle.

```jsx
<TaskCard checkType="temperature" title="Walk-in fridge temp" status="due" time="Due 3:00 PM" />
<TaskCard checkType="cleaning" title="Sanitize prep surfaces" status="upcoming" time="Due 5:00 PM" />
<TaskCard checkType="temperature" title="Freezer temp" status="overdue" time="Was due 1:00 PM" />
<TaskCard checkType="temperature" title="Hot-hold line" status="done" result="64°C" />
<TaskCard checkType="temperature" title="Display fridge" status="failed" result="9°C" />
<TaskCard checkType="opening" title="Opening checklist" status="pending-sync" />
```

`checkType`: temperature / cleaning / allergen / opening / closing / generic. `status`: due / upcoming / overdue / done / failed / pending-sync. Renders the locked StatusBadge on the right; done rows dim + strike the title and show the recorded `result`.
