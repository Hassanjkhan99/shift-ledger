**EvidenceUpload** — camera-first photo evidence, across its full lifecycle. Controlled via `state`.

```jsx
<EvidenceUpload state="idle" onTakePhoto={openCamera} onChooseFile={pickFile} />
<EvidenceUpload state="compressing" fileName="fridge.webp" progress={62} thumbSrc={url} />
<EvidenceUpload state="uploaded" fileName="fridge.webp" fileSize="182 KB" thumbSrc={url}
  hash="9f2a1c7be3..." onRemove={remove} />
<EvidenceUpload state="error" fileName="fridge.webp" thumbSrc={url} onRetry={retry} />
<EvidenceUpload state="offline-queued" fileName="fridge.webp" thumbSrc={url} />
```

States: `idle` (take photo / choose file) → `capturing` → `compressing` (WebP, progress bar) → `uploaded` (✓ + truncated **SHA-256** chip) · `error` (retry) · `offline-queued` (pending StatusBadge, ties to the Today card's pending-sync). Compression + hashing are the caller's job; this renders the states.
