import React from "react";

const CSS = `
.sl-tl{display:flex;gap:12px;font-family:var(--font-sans)}
.sl-tl__rail{display:flex;flex-direction:column;align-items:center;flex-shrink:0;width:34px}
.sl-tl__dot{width:34px;height:34px;border-radius:var(--radius-full);background:var(--muted);color:var(--muted-foreground);display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:600;flex-shrink:0}
.sl-tl__dot svg{width:17px;height:17px}
.sl-tl__dot--system{background:var(--accent);color:var(--primary)}
.sl-tl__dot--edit{background:var(--status-overdue-bg);color:var(--status-overdue-fg)}
.sl-tl__line{flex:1;width:2px;background:var(--border);margin-top:4px;min-height:14px}
.sl-tl--last .sl-tl__line{display:none}
.sl-tl__body{flex:1;min-width:0;padding-bottom:20px}
.sl-tl__head{font-size:14px;color:var(--foreground);line-height:1.45}
.sl-tl__head b{font-weight:600}
.sl-tl__head .sub{color:var(--muted-foreground)}
.sl-tl__time{font-size:12px;color:var(--muted-foreground);font-family:var(--font-mono);margin-top:2px}
.sl-tl__edit{margin-top:9px;border:1px solid var(--border);border-radius:var(--radius-md);background:var(--surface);padding:10px 12px}
.sl-tl__reason{font-size:13px;color:var(--muted-foreground);margin-bottom:7px}
.sl-tl__reason b{color:var(--foreground);font-weight:500}
.sl-tl__diff{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.sl-tl__chip{font-family:var(--font-mono);font-size:13px;padding:2px 7px;border-radius:var(--radius-sm)}
.sl-tl__before{color:var(--status-fail-fg);background:var(--status-fail-bg);text-decoration:line-through}
.sl-tl__after{color:var(--status-pass-fg);background:var(--status-pass-bg)}
.sl-tl__arrow{color:var(--muted-foreground);display:flex}
.sl-tl__arrow svg{width:15px;height:15px}
`;

function ensureStyle(id, css) {
  if (typeof document !== "undefined" && !document.getElementById(id)) {
    const s = document.createElement("style");
    s.id = id; s.textContent = css; document.head.appendChild(s);
  }
}
const I = (p) => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p} />;
const SYSTEM = <I><rect width="16" height="16" x="4" y="4" rx="2" /><rect width="6" height="6" x="9" y="9" rx="1" /><path d="M15 2v2M9 2v2M15 20v2M9 20v2M20 15h2M20 9h2M2 15h2M2 9h2" /></I>;
const ARROW = <I><path d="M5 12h14M12 5l7 7-7 7" /></I>;

function initials(name) {
  return (name || "?").split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase();
}

/**
 * TimelineRow — one entry in the audit history: actor · action · subject · time.
 * When it represents an edit, it renders the before→after change plus the reason.
 * System actors get a distinct icon + tint.
 */
export function TimelineRow({
  actor,
  actorType = "user",
  action,
  subject,
  time,
  edit = null,
  last = false,
  className = "",
  ...props
}) {
  ensureStyle("sl-tl-css", CSS);
  const isSystem = actorType === "system";
  const dotCls = ["sl-tl__dot", isSystem ? "sl-tl__dot--system" : "", edit ? "sl-tl__dot--edit" : ""].filter(Boolean).join(" ");
  return (
    <div data-slot="timeline-row" className={["sl-tl", last ? "sl-tl--last" : "", className].filter(Boolean).join(" ")} {...props}>
      <div className="sl-tl__rail">
        <span className={dotCls}>{isSystem ? SYSTEM : initials(actor)}</span>
        <span className="sl-tl__line" />
      </div>
      <div className="sl-tl__body">
        <div className="sl-tl__head">
          <b>{actor}</b> {action}{subject ? <> <span className="sub">·</span> <b>{subject}</b></> : null}
        </div>
        <div className="sl-tl__time">{time}</div>
        {edit && (
          <div className="sl-tl__edit">
            {edit.reason ? <div className="sl-tl__reason"><b>Reason:</b> {edit.reason}</div> : null}
            <div className="sl-tl__diff">
              <span className="sl-tl__chip sl-tl__before">{edit.before}</span>
              <span className="sl-tl__arrow">{ARROW}</span>
              <span className="sl-tl__chip sl-tl__after">{edit.after}</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
