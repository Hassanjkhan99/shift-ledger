import * as React from "react";

export interface TimelineEdit {
  /** Previous value (rendered struck-through, red). */
  before: string;
  /** New value (rendered green). */
  after: string;
  /** Why the change was made (required for edits in an audit log). */
  reason?: string;
}

/**
 * One entry in the audit timeline: actor · action · subject · time. When `edit` is
 * given it renders the before→after change and the reason — the core of the Timeline
 * screen. System actors (`actorType="system"`) get a distinct icon and tint. Set
 * `last` on the final row to drop the connector line.
 *
 * @startingPoint section="Domain" subtitle="Audit timeline row + before→after edit" viewport="480x280"
 */
export interface TimelineRowProps
  extends React.HTMLAttributes<HTMLDivElement> {
  actor: string;
  /** @default "user" */
  actorType?: "user" | "system";
  /** Verb phrase, e.g. "completed", "edited the reading for". */
  action: string;
  /** The thing acted on, e.g. "Walk-in fridge temp". */
  subject?: string;
  /** Timestamp label, e.g. "16 Sep · 14:58". */
  time: string;
  /** Present when this entry is an edit. */
  edit?: TimelineEdit | null;
  /** Hide the trailing connector line. @default false */
  last?: boolean;
}

export function TimelineRow(props: TimelineRowProps): React.JSX.Element;
