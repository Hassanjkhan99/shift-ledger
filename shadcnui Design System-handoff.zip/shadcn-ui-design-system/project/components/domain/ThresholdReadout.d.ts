import * as React from "react";

/**
 * The hero readout for temperature checks: a large Geist Mono value that recolors
 * green (pass) / red (fail) live against a threshold. Pass a `min`, a `max`, or both
 * to define the acceptable range. Empty/blank renders a muted "—" with no verdict.
 *
 * @startingPoint section="Domain" subtitle="Live pass/fail temperature readout" viewport="700x260"
 */
export interface ThresholdReadoutProps
  extends React.HTMLAttributes<HTMLDivElement> {
  /** Current value (string keeps a trailing "." while typing; number also fine). */
  value: string | number | null;
  /** Unit suffix. @default "°C" */
  unit?: string;
  /** Lower bound of the pass range (inclusive), or null. */
  min?: number | null;
  /** Upper bound of the pass range (inclusive), or null. */
  max?: number | null;
  /** Value size. @default "lg" */
  size?: "md" | "lg" | "xl";
  /** Show the pass/fail StatusBadge under the value. @default true */
  showBadge?: boolean;
  /** Show the threshold hint line ("Must be ≤ 5°C"). @default true */
  showHint?: boolean;
}

export function ThresholdReadout(props: ThresholdReadoutProps): React.JSX.Element;
