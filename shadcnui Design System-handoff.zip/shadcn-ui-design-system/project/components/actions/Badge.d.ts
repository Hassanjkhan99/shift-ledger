import * as React from "react";

export type BadgeVariant = "default" | "secondary" | "destructive" | "outline";

/**
 * A small rounded pill for statuses, counts, and inline labels.
 */
export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Visual style. @default "default" */
  variant?: BadgeVariant;
}

export function Badge(props: BadgeProps): React.JSX.Element;
