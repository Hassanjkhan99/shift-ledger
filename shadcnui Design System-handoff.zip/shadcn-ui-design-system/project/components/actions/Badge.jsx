import React from "react";

const CSS = `
.scn-badge{display:inline-flex;width:fit-content;align-items:center;justify-content:center;gap:.25rem;overflow:hidden;border-radius:var(--radius-full);border:1px solid transparent;padding:.125rem .5rem;font-family:var(--font-sans);font-size:var(--text-xs);line-height:1rem;font-weight:var(--font-weight-medium);white-space:nowrap}
.scn-badge svg{width:.75rem;height:.75rem;pointer-events:none}
.scn-badge-v-default{background:var(--primary);color:var(--primary-foreground)}
.scn-badge-v-secondary{background:var(--secondary);color:var(--secondary-foreground)}
.scn-badge-v-destructive{background:var(--destructive);color:#fff}
.scn-badge-v-outline{border-color:var(--border);color:var(--foreground)}
`;

function ensureStyle(id, css) {
  if (typeof document !== "undefined" && !document.getElementById(id)) {
    const s = document.createElement("style");
    s.id = id;
    s.textContent = css;
    document.head.appendChild(s);
  }
}

/**
 * Badge — a small pill for status, counts, and labels.
 */
export function Badge({ variant = "default", className = "", children, ...props }) {
  ensureStyle("scn-badge-css", CSS);
  const cls = ["scn-badge", `scn-badge-v-${variant}`, className].filter(Boolean).join(" ");
  return (
    <span data-slot="badge" className={cls} {...props}>
      {children}
    </span>
  );
}
