**Badge** — a small rounded pill for status, counts, or short labels.

```jsx
<Badge>New</Badge>
<Badge variant="secondary">Draft</Badge>
<Badge variant="outline">v2.1</Badge>
<Badge variant="destructive">Failed</Badge>
```

Variants: `default`, `secondary`, `destructive`, `outline`. Fully rounded (pill). Icons render at 12px.
