import React from "react";

const CSS = `
.scn-btn{display:inline-flex;align-items:center;justify-content:center;gap:.5rem;white-space:nowrap;border-radius:var(--radius-md);font-family:var(--font-sans);font-size:var(--text-sm);line-height:1.25rem;font-weight:var(--font-weight-medium);transition:background-color .15s ease,color .15s ease,box-shadow .15s ease,opacity .15s ease;cursor:pointer;border:1px solid transparent;outline:none;user-select:none;flex-shrink:0}
.scn-btn:focus-visible{border-color:var(--ring);box-shadow:0 0 0 3px color-mix(in oklab,var(--ring) 50%,transparent)}
.scn-btn:disabled{pointer-events:none;opacity:.5}
.scn-btn svg{width:1rem;height:1rem;flex-shrink:0;pointer-events:none}
.scn-btn:active{opacity:.9}
.scn-btn--default{height:2.25rem;padding:0 1rem}
.scn-btn--default:has(>svg){padding:0 .75rem}
.scn-btn--sm{height:2rem;padding:0 .75rem;gap:.375rem}
.scn-btn--lg{height:2.5rem;padding:0 1.5rem}
.scn-btn--icon{height:2.25rem;width:2.25rem;padding:0}
.scn-btn-v-default{background:var(--primary);color:var(--primary-foreground)}
.scn-btn-v-default:hover{background:color-mix(in oklab,var(--primary) 90%,transparent)}
.scn-btn-v-destructive{background:var(--destructive);color:#fff}
.scn-btn-v-destructive:hover{background:color-mix(in oklab,var(--destructive) 90%,transparent)}
.scn-btn-v-outline{border-color:var(--border);background:var(--background);box-shadow:var(--shadow-xs);color:var(--foreground)}
.scn-btn-v-outline:hover{background:var(--accent);color:var(--accent-foreground)}
.scn-btn-v-secondary{background:var(--secondary);color:var(--secondary-foreground)}
.scn-btn-v-secondary:hover{background:color-mix(in oklab,var(--secondary) 80%,transparent)}
.scn-btn-v-ghost{background:transparent;color:var(--foreground)}
.scn-btn-v-ghost:hover{background:var(--accent);color:var(--accent-foreground)}
.scn-btn-v-link{background:transparent;color:var(--primary);text-underline-offset:4px}
.scn-btn-v-link:hover{text-decoration:underline}
.scn-btn__spinner{width:1rem;height:1rem;flex-shrink:0;animation:scn-spin .7s linear infinite}
@keyframes scn-spin{to{transform:rotate(360deg)}}
`;

function ensureStyle(id, css) {
  if (typeof document !== "undefined" && !document.getElementById(id)) {
    const s = document.createElement("style");
    s.id = id;
    s.textContent = css;
    document.head.appendChild(s);
  }
}

/**
 * Button — the primary action element. Mirrors shadcn/ui variants + sizes.
 */
export function Button({
  variant = "default",
  size = "default",
  loading = false,
  disabled = false,
  className = "",
  children,
  ...props
}) {
  ensureStyle("scn-btn-css", CSS);
  const cls = [
    "scn-btn",
    `scn-btn--${size}`,
    `scn-btn-v-${variant}`,
    className,
  ]
    .filter(Boolean)
    .join(" ");
  return (
    <button data-slot="button" className={cls} disabled={disabled || loading} aria-busy={loading || undefined} {...props}>
      {loading && (
        <svg className="scn-btn__spinner" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M21 12a9 9 0 1 1-6.219-8.56" /></svg>
      )}
      {children}
    </button>
  );
}
