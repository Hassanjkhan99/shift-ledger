**Button** — the primary interactive action element; use it for anything a user clicks to do something.

```jsx
<Button>Continue</Button>
<Button variant="secondary">Cancel</Button>
<Button variant="outline" size="sm">Filter</Button>
<Button variant="destructive">Delete</Button>
<Button variant="ghost" size="icon"><SettingsIcon /></Button>
```

Variants: `default` (solid black/primary), `secondary`, `outline`, `ghost`, `destructive`, `link`.
Sizes: `default` (h-36), `sm` (h-32), `lg` (h-40), `icon` (36×36 square). Icons auto-size to 16px.
