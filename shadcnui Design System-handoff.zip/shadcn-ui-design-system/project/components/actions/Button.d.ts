import * as React from "react";

export type ButtonVariant =
  | "default"
  | "destructive"
  | "outline"
  | "secondary"
  | "ghost"
  | "link";

export type ButtonSize = "default" | "sm" | "lg" | "icon";

/**
 * The primary interactive action element. Use `default` for the main action on a
 * view, `secondary`/`outline` for supporting actions, `ghost` for low-emphasis
 * toolbar actions, `destructive` for dangerous actions, and `link` for inline navigation.
 *
 * @startingPoint section="Actions" subtitle="Button variants & sizes" viewport="700x160"
 */
export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** Visual style. @default "default" */
  variant?: ButtonVariant;
  /** Control height / padding. Use "icon" for square icon-only buttons. @default "default" */
  size?: ButtonSize;
  /** Show a spinner and disable the button. @default false */
  loading?: boolean;
}

export function Button(props: ButtonProps): React.JSX.Element;
