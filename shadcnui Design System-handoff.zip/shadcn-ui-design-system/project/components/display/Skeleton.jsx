import React from "react";

const CSS = `
.scn-skeleton{background:var(--accent);border-radius:var(--radius-md);animation:scn-pulse 1.6s cubic-bezier(.4,0,.6,1) infinite}
@keyframes scn-pulse{50%{opacity:.5}}
`;

function ensureStyle(id, css) {
  if (typeof document !== "undefined" && !document.getElementById(id)) {
    const s = document.createElement("style");
    s.id = id;
    s.textContent = css;
    document.head.appendChild(s);
  }
}

/** Skeleton — an animated placeholder block for loading states. */
export function Skeleton({ className = "", style, ...props }) {
  ensureStyle("scn-skeleton-css", CSS);
  return (
    <div
      data-slot="skeleton"
      className={["scn-skeleton", className].filter(Boolean).join(" ")}
      style={style}
      {...props}
    />
  );
}
