import * as React from "react";

/** A circular user image. Falls back to `fallback` (or initials from `alt`) if the image is missing or fails. */
export interface AvatarProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Image URL. */
  src?: string;
  /** Alt text; also used to derive initials when no fallback is given. */
  alt?: string;
  /** Fallback content shown when there's no image (e.g. "JD"). */
  fallback?: React.ReactNode;
  /** Pixel size (width & height). @default 40 */
  size?: number;
}

export function Avatar(props: AvatarProps): React.JSX.Element;
