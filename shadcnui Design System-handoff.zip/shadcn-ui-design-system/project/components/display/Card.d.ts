import * as React from "react";

/**
 * A bordered, elevated surface. Compose from the parts: `CardHeader` (with
 * `CardTitle` + `CardDescription`), `CardContent`, and `CardFooter`.
 *
 * @startingPoint section="Display" subtitle="Card container + parts" viewport="700x300"
 */
export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {}

export function Card(props: CardProps): React.JSX.Element;
export function CardHeader(props: React.HTMLAttributes<HTMLDivElement>): React.JSX.Element;
export function CardTitle(props: React.HTMLAttributes<HTMLDivElement>): React.JSX.Element;
export function CardDescription(props: React.HTMLAttributes<HTMLDivElement>): React.JSX.Element;
export function CardContent(props: React.HTMLAttributes<HTMLDivElement>): React.JSX.Element;
export function CardFooter(props: React.HTMLAttributes<HTMLDivElement>): React.JSX.Element;
