import * as React from "react";

/** A thin 1px divider. Use `orientation="vertical"` inside a flex row (needs a defined height). */
export interface SeparatorProps extends React.HTMLAttributes<HTMLDivElement> {
  orientation?: "horizontal" | "vertical";
}

export function Separator(props: SeparatorProps): React.JSX.Element;
