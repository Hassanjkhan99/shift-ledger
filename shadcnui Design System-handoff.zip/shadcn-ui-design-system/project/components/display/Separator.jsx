import React from "react";

const CSS = `
.scn-separator{background:var(--border);flex-shrink:0;border:0}
.scn-separator[data-orientation=horizontal]{height:1px;width:100%}
.scn-separator[data-orientation=vertical]{width:1px;height:100%;align-self:stretch}
`;

function ensureStyle(id, css) {
  if (typeof document !== "undefined" && !document.getElementById(id)) {
    const s = document.createElement("style");
    s.id = id;
    s.textContent = css;
    document.head.appendChild(s);
  }
}

/** Separator — a thin divider line, horizontal or vertical. */
export function Separator({ orientation = "horizontal", className = "", ...props }) {
  ensureStyle("scn-separator-css", CSS);
  return (
    <div
      data-slot="separator"
      role="separator"
      data-orientation={orientation}
      className={["scn-separator", className].filter(Boolean).join(" ")}
      {...props}
    />
  );
}
