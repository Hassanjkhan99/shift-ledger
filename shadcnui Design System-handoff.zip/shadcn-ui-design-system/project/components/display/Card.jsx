import React from "react";

const CSS = `
.scn-card{display:flex;flex-direction:column;gap:1.5rem;border-radius:var(--radius-xl);border:1px solid var(--border);background:var(--card);color:var(--card-foreground);padding:1.5rem 0;box-shadow:var(--shadow-sm)}
.scn-card-header{display:grid;grid-auto-rows:min-content;gap:.375rem;padding:0 1.5rem}
.scn-card-title{font-weight:var(--font-weight-semibold);line-height:1;font-size:var(--text-base)}
.scn-card-desc{font-size:var(--text-sm);color:var(--muted-foreground);line-height:1.25rem}
.scn-card-content{padding:0 1.5rem}
.scn-card-footer{display:flex;align-items:center;gap:.5rem;padding:0 1.5rem}
`;

function ensureStyle(id, css) {
  if (typeof document !== "undefined" && !document.getElementById(id)) {
    const s = document.createElement("style");
    s.id = id;
    s.textContent = css;
    document.head.appendChild(s);
  }
}
function cx(base, className) {
  return [base, className].filter(Boolean).join(" ");
}

/** Card — a bordered surface container. Compose with the CardHeader/Title/Description/Content/Footer parts. */
export function Card({ className = "", children, ...props }) {
  ensureStyle("scn-card-css", CSS);
  return (
    <div data-slot="card" className={cx("scn-card", className)} {...props}>
      {children}
    </div>
  );
}
export function CardHeader({ className = "", children, ...props }) {
  return (
    <div data-slot="card-header" className={cx("scn-card-header", className)} {...props}>
      {children}
    </div>
  );
}
export function CardTitle({ className = "", children, ...props }) {
  return (
    <div data-slot="card-title" className={cx("scn-card-title", className)} {...props}>
      {children}
    </div>
  );
}
export function CardDescription({ className = "", children, ...props }) {
  return (
    <div data-slot="card-description" className={cx("scn-card-desc", className)} {...props}>
      {children}
    </div>
  );
}
export function CardContent({ className = "", children, ...props }) {
  return (
    <div data-slot="card-content" className={cx("scn-card-content", className)} {...props}>
      {children}
    </div>
  );
}
export function CardFooter({ className = "", children, ...props }) {
  return (
    <div data-slot="card-footer" className={cx("scn-card-footer", className)} {...props}>
      {children}
    </div>
  );
}
