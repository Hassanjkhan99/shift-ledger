**Card** — a bordered, softly elevated surface. Compose from its parts.

```jsx
<Card style={{maxWidth:360}}>
  <CardHeader>
    <CardTitle>Create project</CardTitle>
    <CardDescription>Deploy your new project in one click.</CardDescription>
  </CardHeader>
  <CardContent>Form fields go here.</CardContent>
  <CardFooter>
    <Button variant="outline">Cancel</Button>
    <Button>Deploy</Button>
  </CardFooter>
</Card>
```

`--radius-xl` corners, 1px `--border`, `--shadow-sm`. Parts have 24px horizontal padding; sections are separated by a 24px gap.
