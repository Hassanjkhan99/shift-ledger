import * as React from "react";

/** An animated pulse placeholder for loading states. Size it via `style`/`className` (width, height). */
export interface SkeletonProps extends React.HTMLAttributes<HTMLDivElement> {}

export function Skeleton(props: SkeletonProps): React.JSX.Element;
