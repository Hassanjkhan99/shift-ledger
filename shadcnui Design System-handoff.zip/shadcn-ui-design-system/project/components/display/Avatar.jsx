import React from "react";

const CSS = `
.scn-avatar{position:relative;display:inline-flex;height:2.5rem;width:2.5rem;flex-shrink:0;overflow:hidden;border-radius:var(--radius-full);user-select:none;vertical-align:middle}
.scn-avatar img{width:100%;height:100%;object-fit:cover;display:block}
.scn-avatar-fallback{display:flex;width:100%;height:100%;align-items:center;justify-content:center;background:var(--muted);color:var(--muted-foreground);font-size:var(--text-sm);font-weight:var(--font-weight-medium)}
`;

function ensureStyle(id, css) {
  if (typeof document !== "undefined" && !document.getElementById(id)) {
    const s = document.createElement("style");
    s.id = id;
    s.textContent = css;
    document.head.appendChild(s);
  }
}

/** Avatar — a rounded user image with an initials fallback. */
export function Avatar({ src, alt = "", fallback, size = 40, className = "", ...props }) {
  ensureStyle("scn-avatar-css", CSS);
  const [errored, setErrored] = React.useState(false);
  const showImg = src && !errored;
  return (
    <span
      data-slot="avatar"
      className={["scn-avatar", className].filter(Boolean).join(" ")}
      style={{ width: size, height: size }}
      {...props}
    >
      {showImg ? (
        <img src={src} alt={alt} onError={() => setErrored(true)} />
      ) : (
        <span className="scn-avatar-fallback">{fallback || alt.slice(0, 2).toUpperCase()}</span>
      )}
    </span>
  );
}
