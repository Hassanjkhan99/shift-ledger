import React from "react";

const CSS = `
.scn-textarea{display:flex;min-height:4rem;width:100%;border-radius:var(--radius-md);border:1px solid var(--input);background:transparent;padding:.5rem .75rem;font-family:var(--font-sans);font-size:var(--text-sm);line-height:1.25rem;color:var(--foreground);box-shadow:var(--shadow-xs);transition:color .15s ease,box-shadow .15s ease,border-color .15s ease;outline:none;resize:vertical;field-sizing:content}
.scn-textarea::placeholder{color:var(--muted-foreground)}
.scn-textarea:focus-visible{border-color:var(--ring);box-shadow:0 0 0 3px color-mix(in oklab,var(--ring) 50%,transparent)}
.scn-textarea:disabled{cursor:not-allowed;opacity:.5}
`;

function ensureStyle(id, css) {
  if (typeof document !== "undefined" && !document.getElementById(id)) {
    const s = document.createElement("style");
    s.id = id;
    s.textContent = css;
    document.head.appendChild(s);
  }
}

/** Textarea — multi-line text field. */
export function Textarea({ className = "", ...props }) {
  ensureStyle("scn-textarea-css", CSS);
  return (
    <textarea
      data-slot="textarea"
      className={["scn-textarea", className].filter(Boolean).join(" ")}
      {...props}
    />
  );
}
