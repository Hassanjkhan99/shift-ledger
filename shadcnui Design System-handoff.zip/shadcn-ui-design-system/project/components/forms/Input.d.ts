import * as React from "react";

/**
 * A single-line text field. Pair with `Label`. Set `aria-invalid` to show the
 * destructive error ring.
 */
export interface InputProps
  extends React.InputHTMLAttributes<HTMLInputElement> {}

export function Input(props: InputProps): React.JSX.Element;
