**Form controls** — Input, Textarea, Label, Checkbox, Switch, Select.

```jsx
<div style={{display:"grid", gap:8, maxWidth:320}}>
  <Label htmlFor="email">Email</Label>
  <Input id="email" type="email" placeholder="you@example.com" />
  <Textarea placeholder="Your message" />
  <label style={{display:"flex", gap:8, alignItems:"center"}}>
    <Checkbox defaultChecked /> Subscribe
  </label>
  <Switch defaultChecked />
  <Select defaultValue="us"><option value="us">US</option><option value="uk">UK</option></Select>
</div>
```

All controls are 36px tall, `--radius-md`, with a 3px focus ring in `--ring`. Checkbox and Switch are controlled (`checked` + `onCheckedChange`) or uncontrolled (`defaultChecked`).
