import React from "react";

const CSS = `
.scn-checkbox{appearance:none;width:1rem;height:1rem;flex-shrink:0;border-radius:var(--radius-sm);border:1px solid var(--input);background:var(--background);box-shadow:var(--shadow-xs);display:inline-flex;align-items:center;justify-content:center;cursor:pointer;transition:background .15s ease,border-color .15s ease,box-shadow .15s ease;padding:0;color:var(--primary-foreground)}
.scn-checkbox[data-state=checked]{background:var(--primary);border-color:var(--primary)}
.scn-checkbox:focus-visible{border-color:var(--ring);box-shadow:0 0 0 3px color-mix(in oklab,var(--ring) 50%,transparent)}
.scn-checkbox:disabled{cursor:not-allowed;opacity:.5}
.scn-checkbox svg{width:.75rem;height:.75rem}
`;

function ensureStyle(id, css) {
  if (typeof document !== "undefined" && !document.getElementById(id)) {
    const s = document.createElement("style");
    s.id = id;
    s.textContent = css;
    document.head.appendChild(s);
  }
}

/** Checkbox — a toggleable box. Controlled via `checked`+`onCheckedChange`, or uncontrolled via `defaultChecked`. */
export function Checkbox({
  checked,
  defaultChecked = false,
  onCheckedChange,
  disabled = false,
  className = "",
  ...props
}) {
  ensureStyle("scn-checkbox-css", CSS);
  const [internal, setInternal] = React.useState(!!defaultChecked);
  const isControlled = checked !== undefined;
  const val = isControlled ? checked : internal;
  const toggle = () => {
    if (disabled) return;
    const next = !val;
    if (!isControlled) setInternal(next);
    if (onCheckedChange) onCheckedChange(next);
  };
  return (
    <button
      type="button"
      role="checkbox"
      aria-checked={val}
      data-slot="checkbox"
      data-state={val ? "checked" : "unchecked"}
      disabled={disabled}
      onClick={toggle}
      className={["scn-checkbox", className].filter(Boolean).join(" ")}
      {...props}
    >
      {val && (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
          <path d="M20 6 9 17l-5-5" />
        </svg>
      )}
    </button>
  );
}
