import React from "react";

const CSS = `
.scn-switch{appearance:none;position:relative;display:inline-flex;align-items:center;height:1.15rem;width:2rem;flex-shrink:0;border-radius:var(--radius-full);border:1px solid transparent;background:var(--input);box-shadow:var(--shadow-xs);cursor:pointer;transition:background-color .15s ease,box-shadow .15s ease;padding:0}
.scn-switch[data-state=checked]{background:var(--primary)}
.scn-switch:focus-visible{box-shadow:0 0 0 3px color-mix(in oklab,var(--ring) 50%,transparent)}
.scn-switch:disabled{cursor:not-allowed;opacity:.5}
.scn-switch-thumb{pointer-events:none;display:block;width:1rem;height:1rem;border-radius:var(--radius-full);background:var(--background);box-shadow:var(--shadow-sm);transition:transform .15s ease;transform:translateX(0)}
.scn-switch[data-state=checked] .scn-switch-thumb{transform:translateX(calc(100% - 2px))}
`;

function ensureStyle(id, css) {
  if (typeof document !== "undefined" && !document.getElementById(id)) {
    const s = document.createElement("style");
    s.id = id;
    s.textContent = css;
    document.head.appendChild(s);
  }
}

/** Switch — an on/off toggle. Controlled via `checked`+`onCheckedChange` or uncontrolled via `defaultChecked`. */
export function Switch({
  checked,
  defaultChecked = false,
  onCheckedChange,
  disabled = false,
  className = "",
  ...props
}) {
  ensureStyle("scn-switch-css", CSS);
  const [internal, setInternal] = React.useState(!!defaultChecked);
  const isControlled = checked !== undefined;
  const val = isControlled ? checked : internal;
  const toggle = () => {
    if (disabled) return;
    const next = !val;
    if (!isControlled) setInternal(next);
    if (onCheckedChange) onCheckedChange(next);
  };
  return (
    <button
      type="button"
      role="switch"
      aria-checked={val}
      data-slot="switch"
      data-state={val ? "checked" : "unchecked"}
      disabled={disabled}
      onClick={toggle}
      className={["scn-switch", className].filter(Boolean).join(" ")}
      {...props}
    >
      <span className="scn-switch-thumb" data-slot="switch-thumb" />
    </button>
  );
}
