import * as React from "react";

/** A toggleable checkbox. Controlled (`checked` + `onCheckedChange`) or uncontrolled (`defaultChecked`). */
export interface CheckboxProps
  extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, "onChange"> {
  /** Controlled checked state. */
  checked?: boolean;
  /** Initial state when uncontrolled. @default false */
  defaultChecked?: boolean;
  /** Fired with the new boolean when toggled. */
  onCheckedChange?: (checked: boolean) => void;
  disabled?: boolean;
}

export function Checkbox(props: CheckboxProps): React.JSX.Element;
