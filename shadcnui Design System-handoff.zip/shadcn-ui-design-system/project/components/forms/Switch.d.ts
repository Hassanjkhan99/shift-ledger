import * as React from "react";

/** An on/off toggle. Controlled (`checked` + `onCheckedChange`) or uncontrolled (`defaultChecked`). */
export interface SwitchProps
  extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, "onChange"> {
  checked?: boolean;
  defaultChecked?: boolean;
  onCheckedChange?: (checked: boolean) => void;
  disabled?: boolean;
}

export function Switch(props: SwitchProps): React.JSX.Element;
