import React from "react";

const CHEVRON =
  "data:image/svg+xml;utf8," +
  encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="%23737373" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>'
  );

const CSS = `
.scn-select{height:2.25rem;width:100%;border-radius:var(--radius-md);border:1px solid var(--input);background-color:transparent;padding:0 2rem 0 .75rem;font-family:var(--font-sans);font-size:var(--text-sm);line-height:1.25rem;color:var(--foreground);box-shadow:var(--shadow-xs);appearance:none;cursor:pointer;outline:none;transition:color .15s ease,box-shadow .15s ease,border-color .15s ease;background-image:url("${CHEVRON}");background-repeat:no-repeat;background-position:right .5rem center;background-size:1rem}
.scn-select:focus-visible{border-color:var(--ring);box-shadow:0 0 0 3px color-mix(in oklab,var(--ring) 50%,transparent)}
.scn-select:disabled{cursor:not-allowed;opacity:.5}
`;

function ensureStyle(id, css) {
  if (typeof document !== "undefined" && !document.getElementById(id)) {
    const s = document.createElement("style");
    s.id = id;
    s.textContent = css;
    document.head.appendChild(s);
  }
}

/** Select — a native styled dropdown. Pass `<option>` children. */
export function Select({ className = "", children, ...props }) {
  ensureStyle("scn-select-css", CSS);
  return (
    <select data-slot="select" className={["scn-select", className].filter(Boolean).join(" ")} {...props}>
      {children}
    </select>
  );
}
