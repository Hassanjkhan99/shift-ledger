import * as React from "react";

/** A multi-line text field. Grows with content; pair with `Label`. */
export interface TextareaProps
  extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {}

export function Textarea(props: TextareaProps): React.JSX.Element;
