import * as React from "react";

/** An accessible caption for a form control. Use `htmlFor` to bind to an input id. */
export interface LabelProps
  extends React.LabelHTMLAttributes<HTMLLabelElement> {}

export function Label(props: LabelProps): React.JSX.Element;
