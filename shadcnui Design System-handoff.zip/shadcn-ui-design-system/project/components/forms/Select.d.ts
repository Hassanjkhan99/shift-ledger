import * as React from "react";

/** A native styled dropdown. Provide `<option>` children; use `value`+`onChange` or `defaultValue`. */
export interface SelectProps
  extends React.SelectHTMLAttributes<HTMLSelectElement> {}

export function Select(props: SelectProps): React.JSX.Element;
