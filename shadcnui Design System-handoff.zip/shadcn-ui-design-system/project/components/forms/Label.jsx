import React from "react";

const CSS = `
.scn-label{display:inline-flex;align-items:center;gap:.5rem;font-family:var(--font-sans);font-size:var(--text-sm);line-height:1;font-weight:var(--font-weight-medium);color:var(--foreground);user-select:none}
.scn-label[data-disabled=true]{opacity:.5;cursor:not-allowed}
`;

function ensureStyle(id, css) {
  if (typeof document !== "undefined" && !document.getElementById(id)) {
    const s = document.createElement("style");
    s.id = id;
    s.textContent = css;
    document.head.appendChild(s);
  }
}

/** Label — accessible caption for a form control. */
export function Label({ className = "", children, ...props }) {
  ensureStyle("scn-label-css", CSS);
  return (
    <label data-slot="label" className={["scn-label", className].filter(Boolean).join(" ")} {...props}>
      {children}
    </label>
  );
}
