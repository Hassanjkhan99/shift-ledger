import React from "react";

const CSS = `
.scn-input{display:flex;height:2.25rem;width:100%;min-width:0;border-radius:var(--radius-md);border:1px solid var(--input);background:transparent;padding:.25rem .75rem;font-family:var(--font-sans);font-size:var(--text-sm);line-height:1.25rem;color:var(--foreground);box-shadow:var(--shadow-xs);transition:color .15s ease,box-shadow .15s ease,border-color .15s ease;outline:none}
.scn-input::placeholder{color:var(--muted-foreground)}
.scn-input:focus-visible{border-color:var(--ring);box-shadow:0 0 0 3px color-mix(in oklab,var(--ring) 50%,transparent)}
.scn-input:disabled{cursor:not-allowed;opacity:.5}
.scn-input[aria-invalid=true]{border-color:var(--destructive);box-shadow:0 0 0 3px color-mix(in oklab,var(--destructive) 20%,transparent)}
`;

function ensureStyle(id, css) {
  if (typeof document !== "undefined" && !document.getElementById(id)) {
    const s = document.createElement("style");
    s.id = id;
    s.textContent = css;
    document.head.appendChild(s);
  }
}

/** Input — single-line text field. */
export function Input({ className = "", type = "text", ...props }) {
  ensureStyle("scn-input-css", CSS);
  return (
    <input
      type={type}
      data-slot="input"
      className={["scn-input", className].filter(Boolean).join(" ")}
      {...props}
    />
  );
}
